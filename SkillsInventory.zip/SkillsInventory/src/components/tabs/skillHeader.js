import React from "react";

function SkillHeader() {
  return (
    <tr className="hideMob">
      <th width="10%">SKILLSET</th>
      <th width="17%">EXPERTISE LEVEL</th>
      <th width="10%">DATE</th>
      <th width="10%">EXPERIENCE</th>
      <th width="8%">PRACTICING</th>
      <th width="10%">LAST USED</th>
      <th width="27%">DM COMMENT</th>
      <th width="10%"> ACTION</th>
    </tr >
  );
}

export default SkillHeader;
