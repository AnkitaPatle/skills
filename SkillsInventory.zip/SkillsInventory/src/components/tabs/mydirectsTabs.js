// This component contains tabs which are displayed on dashboard
import React from "react";
import PropTypes from "prop-types";
import { NavLink } from "react-router-dom";
import { withStyles } from "@material-ui/core/styles";
import "./tabs.css";
import AppBar from "@material-ui/core/AppBar";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import Typography from "@material-ui/core/Typography";
import DashboardSkills from "../../containers/dashboardskill/dashboardskills";
import DirectsSkillHeader from "../../containers/manager/mydirects/directskillHeader";
import MyDirectsTable from '../../containers/manager/mydirects/mydirectTable/mydirectsTable';
import { DeleteSkillsModal } from '../../containers/delete-skills-modal/delete-skills-modal.component';
import * as actions from "../../containers/manager/approvskillActions";
import EditComponent from "./editComponent";
import { toastr } from "react-redux-toastr";
import { withRouter } from 'react-router-dom';
import { API_URL } from '../../config';
import StarRating from "../starRating/starRating";
import CommentComponent from '../../containers/manager/mydirects/dmSkillComment';
import AddSkillDm from '../../containers/manager/mydirects/addskillDM';
import './../starRating/starRating.css';


function TabContainer(props) {
  return (
    <Typography component="div" style={{ padding: 8 * 0 }}>
      {props.children}
    </Typography>
  );
}

TabContainer.propTypes = {
  children: PropTypes.node.isRequired
};

const styles = theme => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper,
    margin: "5% 0",
    background: "#eeeeee"
  },
  indicator: {
    backgroundColor: "#0693e8"
  },
  flexContainer: {
    borderBottom: "1px solid #f4f4f4"
  },
  tabRoot: { borderColor: "#fff" }
});

class MydirectsTabs extends React.Component {
  state = {
    value: 0,
    addYearList: [],
    isModalOpen: false,
    redirect: false,
    isComentModalOpen: false,
    skillData: {},
    disable:true
  };
  multipleskillinfoexpert = [];
  multipleskillinfopractitioner = [];
  multipleskillinfonovice = [];
  multipleskillinfoAll = [];

  handleChange = (event, value) => {
    this.setState({disable:true});
    this.setState({ value });
  };

  onChangeExpertiseLevel(rating) {
    this.setState({ expertiseLevel: rating });
    this.setState({ message: "" });
  }

  handleAllCheckboxChangeexpert = (skillstoapprove, data) => {
    if (data != undefined)
    {
      this.multipleskillinfoexpert = [];
      this.multipleskillinfopractitioner = [];
      this.multipleskillinfonovice = [];
      this.multipleskillinfoAll = [];
      for (let i = 0; i <= data.length - 1; i++)
      {
        if (skillstoapprove)
        {
          document.getElementById("expertChk" + i).checked = true;
          this.multipleskillinfoexpert.push(data[i]);
        } else
        {
          document.getElementById("expertChk" + i).checked = false;
        }
      }
      if(this.multipleskillinfoexpert.length > 0)
      {
        this.setState({disable:false})
      }
      else{
        this.setState({disable:true})
      }
      
    }
  };

  handleCheckboxChangeexpert = (e, item, index) => {
    if (e.target.checked)
    {
      this.multipleskillinfoexpert.push(item);
    } else
    {
      for (let i = 0; i < this.multipleskillinfoexpert.length; i++)
      {
        if (
          this.multipleskillinfoexpert[i].skillname === item.skillname &&
          this.multipleskillinfoexpert[i].username === item.username
        )
        {
          this.multipleskillinfoexpert.splice(i, 1);
        }
      }
    }
    if (this.multipleskillinfoexpert.length > 0)
    {
      this.setState({ disable: false });
    } else
    {
      this.setState({ disable: true });
    }
  };

  handleAllCheckboxChangepractitioner = (skillstoapprove, data) => {
    if (data != undefined)
    {
      this.multipleskillinfopractitioner = [];
      this.multipleskillinfoexpert = [];
      this.multipleskillinfonovice = [];
      this.multipleskillinfoAll = [];
      for (let i = 0; i <= data.length - 1; i++)
      {
        if (skillstoapprove)
        {
          document.getElementById("interChk" + i).checked = true;
          this.multipleskillinfopractitioner.push(data[i]);
        } else
        {
          document.getElementById("interChk" + i).checked = false;
        }
      }
      if(this.multipleskillinfopractitioner.length > 0)
      {
        this.setState({disable:false})
      }
      else{
        this.setState({disable:true})
      }
    }
  };

  handleCheckboxChangepractitioner = (e, item, index) => {
    if (e.target.checked)
    {
      this.multipleskillinfopractitioner.push(item);
    } else
    {
      for (let i = 0; i < this.multipleskillinfopractitioner.length; i++)
      {
        if (
          this.multipleskillinfopractitioner[i].skillname === item.skillname &&
          this.multipleskillinfopractitioner[i].username === item.username
        )
        {
          this.multipleskillinfopractitioner.splice(i, 1);
        }
      }
    }
    if (this.multipleskillinfopractitioner.length > 0)
    {
      this.setState({ disable: false });
    } else
    {
      this.setState({ disable: true });
    }
  };

  handleAllCheckboxChangenovice = (skillstoapprove, data) => {
    if (data != undefined)
    {
      this.multipleskillinfonovice = [];
      this.multipleskillinfoexpert = [];
      this.multipleskillinfopractitioner = [];
      this.multipleskillinfoAll = [];
      for (let i = 0; i <= data.length - 1; i++)
      {
        if (skillstoapprove)
        {
          document.getElementById("noviceChk" + i).checked = true;
          this.multipleskillinfonovice.push(data[i]);
        } else
        {
          document.getElementById("noviceChk" + i).checked = false;
        }
      }
      if(this.multipleskillinfonovice.length > 0)
      {
        this.setState({disable:false})
      }
      else{
        this.setState({disable:true})
      }
    }
  };

  handleCheckboxChangenovice = (e, item, index) => {
    if (e.target.checked)
    {
      this.multipleskillinfonovice.push(item);
    } else
    {
      for (let i = 0; i < this.multipleskillinfonovice.length; i++)
      {
        if (
          this.multipleskillinfonovice[i].skillname === item.skillname &&
          this.multipleskillinfonovice[i].username === item.username
        )
        {
          this.multipleskillinfonovice.splice(i, 1);
        }
      }
    }
    if (this.multipleskillinfonovice.length > 0)
    {
      this.setState({ disable: false });
    } else
    {
      this.setState({ disable: true });
    }
  };

  handleAllCheckboxChangeAll = (skillstoapprove, data) => {
    if (data != undefined)
    {
      this.multipleskillinfoAll = [];
      this.multipleskillinfoexpert = [];
      this.multipleskillinfopractitioner = [];
      this.multipleskillinfonovice = [];
      for (let i = 0; i <= data.length - 1; i++)
      {
        if (skillstoapprove)
        {
          document.getElementById("allChk" + i).checked = true;
          this.multipleskillinfoAll.push(data[i]);
        } else
        {
          document.getElementById("allChk" + i).checked = false;
        }
      }
      if (this.multipleskillinfoAll.length > 0)
      {
        this.setState({ disable: false });
      } else
      {
        this.setState({ disable: true });
      }
    }
  };

  handleCheckboxChangeAll = (e, item, index) => {
    if (e.target.checked)
    {
      this.multipleskillinfoAll.push(item);
    } else
    {
      for (let i = 0; i < this.multipleskillinfoAll.length; i++)
      {
        if (
          this.multipleskillinfoAll[i].skillname === item.skillname &&
          this.multipleskillinfoAll[i].username === item.username
        )
        {
          this.multipleskillinfoAll.splice(i, 1);
        }
      }
    }
    if (this.multipleskillinfoAll.length > 0)
    {
      this.setState({ disable: false });
    } else
    {
      this.setState({ disable: true });
    }
  };

  approvemultipleskill() {
    this.setState({disable:true})
    if(this.multipleskillinfoexpert.length > 0 || this.multipleskillinfopractitioner.length > 0 || this.multipleskillinfonovice.length > 0 || this.multipleskillinfoAll.length > 0)
    {

      if (this.multipleskillinfoexpert.length > 0)
      {
         if (this.multipleskillinfoexpert.length == 1){
        const { dispatch } = this.props;
        dispatch(actions.ApproveMultipleSkills(this.multipleskillinfoexpert)).then((res)=>{
          toastr.success('Success', 'Skill approved successfully.', { showCloseButton: false,
          timeOut: 3000 })
          this.props.reloaddata();
        });
      document.getElementById("expertchkAll").checked = false;
      var allchkexpert = document.getElementsByClassName("chkallexpert");
      for (let i = 0; i < allchkexpert.length; i++) {
        allchkexpert[i].checked = false;
      }
        this.multipleskillinfoexpert = [];
      }else {
        const { dispatch } = this.props;
        dispatch(actions.ApproveMultipleSkills(this.multipleskillinfoexpert)).then((res)=>{
          toastr.success('Success', 'Skills approved successfully.', { showCloseButton: false,
          timeOut: 3000 })
          this.props.reloaddata();
        });
      document.getElementById("expertchkAll").checked = false;
      var allchkexpert = document.getElementsByClassName("chkallexpert");
      for (let i = 0; i < allchkexpert.length; i++) {
        allchkexpert[i].checked = false;
      }
        this.multipleskillinfoexpert = [];        
      }
      }

      if (this.multipleskillinfopractitioner.length > 0)
      {
        if (this.multipleskillinfopractitioner.length == 1){
        const { dispatch } = this.props;
        dispatch(actions.ApproveMultipleSkills(this.multipleskillinfopractitioner)).then((res)=>{
          toastr.success('Success', 'Skill approved successfully.', { showCloseButton: false,
          timeOut: 3000 })
          this.props.reloaddata();              
        });
        document.getElementById("interchkAll").checked = false;
        var allchkinter = document.getElementsByClassName("chkallinter");
      for (let i = 0; i < allchkinter.length; i++) {
        allchkinter[i].checked = false;
      }
        this.multipleskillinfopractitioner = [];
      }else{
        const { dispatch } = this.props;
        dispatch(actions.ApproveMultipleSkills(this.multipleskillinfopractitioner)).then((res)=>{
          toastr.success('Success', 'Skills approved successfully.', { showCloseButton: false,
          timeOut: 3000 })
          this.props.reloaddata();              
        });   
        document.getElementById("interchkAll").checked = false;
        var allchkinter = document.getElementsByClassName("chkallinter");
      for (let i = 0; i < allchkinter.length; i++) {
        allchkinter[i].checked = false;
      }
        this.multipleskillinfopractitioner = [];    
      }
      }

      if (this.multipleskillinfonovice.length > 0)
      {
        if (this.multipleskillinfonovice.length == 1){
        const { dispatch } = this.props;
        dispatch(actions.ApproveMultipleSkills(this.multipleskillinfonovice)).then((res)=>{
          toastr.success('Success', 'Skill approved successfully.', { showCloseButton: false,
          timeOut: 3000 })
          this.props.reloaddata();
        });
        document.getElementById("novicechkAll").checked = false;
        var allchknovice = document.getElementsByClassName("chkallnovice");
      for (let i = 0; i < allchknovice.length; i++) {
        allchknovice[i].checked = false;
      }
        this.multipleskillinfonovice = [];
      }else{
        const { dispatch } = this.props;
        dispatch(actions.ApproveMultipleSkills(this.multipleskillinfonovice)).then((res)=>{
          toastr.success('Success', 'Skills approved successfully.', { showCloseButton: false,
          timeOut: 3000 })
          this.props.reloaddata();
        });
        document.getElementById("novicechkAll").checked = false;
        var allchknovice = document.getElementsByClassName("chkallnovice");
      for (let i = 0; i < allchknovice.length; i++) {
        allchknovice[i].checked = false;
      }
        this.multipleskillinfonovice = [];
      }
      }

      if (this.multipleskillinfoAll.length > 0)
      {
        if (this.multipleskillinfoAll.length == 1){
        const { dispatch } = this.props;
        dispatch(actions.ApproveMultipleSkills(this.multipleskillinfoAll)).then((res)=>{
           toastr.success('Success', 'Skill approved successfully.', { showCloseButton: false,
          timeOut: 3000 })
          this.props.reloaddata();
        });
        document.getElementById("allChkchkAll").checked = false;
        var allchk = document.getElementsByClassName("chkall");
      for (let i = 0; i < allchk.length; i++) {
        allchk[i].checked = false;
      }
        this.multipleskillinfoAll = [];
      }else{
         const { dispatch } = this.props;
        dispatch(actions.ApproveMultipleSkills(this.multipleskillinfoAll)).then((res)=>{
           toastr.success('Success', 'Skills approved successfully.', { showCloseButton: false,
          timeOut: 3000 })
          this.props.reloaddata();
        });
        document.getElementById("allChkchkAll").checked = false;
        var allchk = document.getElementsByClassName("chkall");
      for (let i = 0; i < allchk.length; i++) {
        allchk[i].checked = false;
      }
        this.multipleskillinfoAll = [];
      }
      }

    }
    else{
      toastr.warning('Warning', 'Please select Skill to Approve!', { showCloseButton: false,
        timeOut: 3000 })
    }
        
   this.setState({disable:false})
  }

  addskillDiredct = data => {
    this.setState({ isModalOpen: true });
    this.state.addDirectSkill = { username: data.username, status: "A" };
  };

  commentskillDiredct = data => {
    this.setState({ isComentModalOpen: true });
    this.state.skillData = { skillData: data };
  };

  addSkillDirect = skillset => {
    if (skillset.level === "")
    {
      skillset.level = "Novice";
    }
    const { dispatch } = this.props;
    dispatch(actions.AddDirectSkills(skillset)).then(data => {
      toastr.success('Success', 'Skill Added Successfully.', { showCloseButton: false,
        timeOut: 3000 })
    });
    this.setState({ isModalOpen: false });
    this.props.reloaddata();
  };
  close() {
    this.setState({ isModalOpen: false });
  }

  closeCommentBox() {
    this.setState({ isComentModalOpen: false });
  }

  getEmployeeInfo = (data) => {
    window.open('', data, 'height=250,width=250');
  }

  renderOnEmployee = (e, empData) => {    
    sessionStorage.setItem("empUsername", empData.username)
    this.props.history.push('/empProfile');
  }

  sendCommentToEmployee = (SkillData) => {
    const { dispatch } = this.props;
    dispatch(actions.sendCommentToEmployee(SkillData)).then(data => {
      toastr.success('Success', 'Comment sent successfully.', { showCloseButton: false,
        timeOut: 3000 });
      this.closeCommentBox();
    });
    this.props.reloaddata();
  }

  render() {
    const { classes } = this.props;
    const { value } = this.state;
    const empdata = this.props.alldata;
    const expert = this.props.childData;
    const intermediat = this.props.practitionerData;
    const novice = this.props.noViceData;
    const pendingList = [];
    const approvedList = [];
    empdata.map(
      ele =>
        ele.skillStatus === "pending"
          ? pendingList.push(ele)
          : approvedList.push(ele)
    );
    const pendingListexpert = [];
    const approvedListexpert = [];
    if(expert !== undefined)
    {
      expert.map(
        ele =>
          ele.skillStatus === "pending"
            ? pendingListexpert.push(ele)
            : approvedListexpert.push(ele)
      );
    }
    const pendingListintermediat = [];
    const approvedListintermediat = [];
    if(intermediat !== undefined)
    {
    intermediat.map(
      ele =>
        ele.skillStatus === "pending"
          ? pendingListintermediat.push(ele)
          : approvedListintermediat.push(ele)
    );
    }
    const pendingListnovice = [];
    const approvedListnovice = [];
    if(novice !== undefined)
    {
    novice.map(
      ele =>
        ele.skillStatus === "pending"
          ? pendingListnovice.push(ele)
          : approvedListnovice.push(ele)
    );
    }
  
    return (
      <div className={classes.root}>
        <AppBar position="static">
          <div className="row tabs">
            <div className="col-md-9 tabmenu hideMob">
              <Tabs
                value={value}
                onChange={this.handleChange}
                classes={{
                  indicator: classes.indicator,
                  flexContainer: classes.flexContainer
                }}
              >
                <Tab id="All" label="All" className="all" classes={{ root: classes.tabRoot }} />
                <Tab id="expert" label="Expert" className="expert" />
                <Tab id="practitioner" label="Practitioner" className="practitioner" />
                <Tab id="novice" label="Novice" className="novice" />
              </Tabs>
            </div>
           
             <div className="col-md-9 tabmenu showMob">
              <Tabs
                value={value}
                onChange={this.handleChange}
                classes={{
                  indicator: classes.indicator,
                  flexContainer: classes.flexContainer
                }}
              >
                <Tab id="All" label="All" className="all" classes={{ root: classes.tabRoot }} />
                <Tab id="expert"  label="Expert" className="expert" />
                <Tab id="practitioner" label="Practitioner" className="practitioner" />
                <Tab id="novice" label="Novice" className="novice" />   
                    
              </Tabs>
            </div>
            <div className="col-md-3 newskillbutton">
              <button
                type="submit"
                id="approveAllbtn"
                className="custom-btn float-right approvenewskill"
                onClick={e => {
                  this.approvemultipleskill();
                }}
                disabled = {this.state.disable}
              >
                Approve Skills
                </button>
            </div>
          </div>
        </AppBar>

        {value === 0 && (
          <TabContainer>
            <table className="table dashboard-skill-table">
              <tbody>
                <tr>
                  <td colSpan="4" className="no-border">
                    <i className="fa fa-square" aria-hidden="true" /> Skillset
                    available for Manager Approval!
                  </td>
                </tr>
                <tr className="hideMob">

                  <th width="2%">
                    <div className="custom-control custom-checkbox custom-checkbox-field">
                      <input type="checkbox" className="custom-control-input" id="allChkchkAll" name="allChkchkAll"
                        onChange={e => {
                          this.handleAllCheckboxChangeAll(
                            e.target.checked,
                            pendingList
                          );
                        }}
                      />
                      <label className="custom-control-label" htmlFor="allChkchkAll"></label>
                    </div>
                  </th>
                  <th width="15%">EMPLOYEE NAME</th>
                  <th width="12%">SKILLSET</th>
                  <th width="10%">EXPERTISE LEVEL</th>
                  <th width="10%">EXPERIENCE</th>
                  <th width="10%">PRACTICING</th>
                  <th width="10%">LAST USED</th>
                  <th width="15%">DM COMMENT</th>
                  <th width="10%">ACTION</th>
                </tr>

                {
                  empdata && empdata.length > 0 ? (
                  empdata && empdata.map((ele, i) => (
                    <tr className={ele.skillStatus === "pending" ? "pending-notation" : ""}>
                     { ele.skillStatus === "pending" ? <td style={{ width: "50px" }}>
                        <div className="custom-control custom-checkbox custom-checkbox-field">
                          <input type="checkbox" className="custom-control-input chkall" id={"allChk" + i} name={"allChk" + i} ischecked={this.state.ischecked}
                            onChange={e => {
                              this.handleCheckboxChangeAll(e, ele, i);
                            }}
                          />
                          <label className="custom-control-label" htmlFor={"allChk" + i}></label>
                        </div>
                      </td> : <td></td> }                     

                      <td className="">
                        <div className="hideMob">
                        <div className="table-skillset ask-expert-table-col-name">
                          {ele.profilePic !== "" ? <img src={API_URL + "/" + ele.profilePic} /> :
                            <img src={require("./../../assets/images/profile.jpg")} />}
                          <span className="textcolor" onClick={e => this.renderOnEmployee(e, ele)}>{ele.firstname} {ele.lastname}</span>
                        </div></div>                       
                         <div className="showMob flex-column">
                          <div className="table-skillset ask-expert-table-col-nameInMob">
                          {ele.profilePic !== "" ? <img src={API_URL + "/" + ele.profilePic} /> :
                            <img src={require("./../../assets/images/profile.jpg")} />}                          
                            <span className="textcolorInMob" onClick={e => this.renderOnEmployee(e, ele)}>{ele.firstname} {ele.lastname}</span>
                        </div>  
                          <div><b>Skillset: </b>{ele.skillname}</div>
                          <div><b>Expertise Level: </b>
                           <StarRating
                            handleRatingChangeProp={this.onChangeExpertiseLevel.bind(this)}
                            rating={ele.level} disableClick={true} >
                          </StarRating>
                          </div>
                          <div><b>Experience: </b>{ele.experience}</div>
                          <div><b>Practicing: </b>{ele.currentStatus === "Practising" ? "Yes" : "No"}</div>
                          <div><b>Last used/Since using: </b>{ele.year}</div>
                          <div><b>Dm Comment: </b>{ele.comment}</div>
                          <div>
                            <span onClick={this.addskillDiredct.bind(this, ele)} className="textcolorInMob">Add skill</span> &nbsp;&nbsp;|&nbsp;&nbsp;
                            <span onClick={this.commentskillDiredct.bind(this, ele)} className="textcolorInMob">MNGR Comment</span>
                          </div>
                        </div>
                      </td>
                    
                      <td className="hideMob">
                        <div className="table-skillset">{ele.skillname} </div>
                      </td>

                      <td className="hideMob">
                        <div className="starcontainer">
                          {/* <StarRating
                            handleRatingChangeProp={this.onChangeExpertiseLevel.bind(this)}
                            rating={ele.level} disableClick={true} >
                          </StarRating> */}
                          {ele.level === "Novice" ? <div> <i className="fa fa-star fa-lg Novice" aria-hidden="true"></i><i className="fa fa-star fa-lg" aria-hidden="true"></i><i className="fa fa-star fa-lg" aria-hidden="true"></i><p>Novice</p></div> : 
                        ele.level === "Practitioner" ? <div> <i className="fa fa-star fa-lg Practitioner" aria-hidden="true"></i><i className="fa fa-star fa-lg Practitioner" aria-hidden="true"></i><i className="fa fa-star fa-lg" aria-hidden="true"></i><p>Practitioner</p></div> :
                        <div> <i className="fa fa-star fa-lg Expert" aria-hidden="true"></i><i className="fa fa-star fa-lg Expert" aria-hidden="true"></i><i className="fa fa-star fa-lg Expert" aria-hidden="true"></i><p>Expert</p></div>}
                          {/* <i className="fa fa-star fa-lg Novice"></i><p>Novice</p> */}
                        </div>
                      </td>

                      <td className="hideMob">
                        <div className="table-skillset">{ele.experience}</div>
                      </td>
                      
                      <td className="hideMob">
                        {ele.currentStatus === "Practising" ? <div className="table-skillset">Yes</div> : <div className="table-skillset">No</div>}
                      </td>

                      <td className="hideMob">
                        <div className="table-skillset"> {ele.year}</div>
                      </td>

                      <td className="hideMob">
                        <div className="table-skillset"> {ele.comment}</div>
                      </td>

                      <td className="hideMob">
                        <p onClick={this.addskillDiredct.bind(this, ele)} className="textcolor">Add skill</p> 
                        <p onClick={this.commentskillDiredct.bind(this, ele)} className="textcolor">MNGR Comment</p>
                      </td>
                    </tr>
                  )
                  )) : <tr><td className="tableStyle"> No data available!</td> </tr>}
              </tbody>
            </table>
          </TabContainer>
        )}

        {value === 1 && (
          <TabContainer>
            <table className="table dashboard-skill-table">
              <tbody>
              <tr>
                  <td colSpan="4" className="no-border">
                    <i className="fa fa-square" aria-hidden="true" /> Skillset
                    available for Manager Approval!
                  </td>
                </tr>
                <tr className="hideMob">
                  <th width="2%">
                    <div className="custom-control custom-checkbox custom-checkbox-field">
                      <input type="checkbox" className="custom-control-input" id="expertchkAll" name="expertchkAll" onChange={e => {
                        this.handleAllCheckboxChangeexpert(
                          e.target.checked,
                          pendingListexpert
                        );
                      }} />
                      <label className="custom-control-label" htmlFor="expertchkAll"></label>
                    </div>
                  </th>
                  <th width="15%">EMPLOYEE NAME</th>
                  <th width="12%">SKILLSET</th>
                  <th width="10%">EXPERTISE LEVEL</th>
                  <th width="10%">EXPERIENCE</th>
                  <th width="10%">PRACTICING</th>
                  <th width="10%">LAST USED</th>
                  <th width="15%">DM COMMENT</th>
                  <th width="10%">ACTION</th>
                </tr>
                {this.props.childData != undefined ? (
                  this.props.childData.map((ele, i) => (
                    <tr className={ele.skillStatus === "pending" ? "pending-notation" : ""} >
                    { ele.skillStatus === "pending" ?  <td style={{ width: "50px" }}>
                    <div className="custom-control custom-checkbox custom-checkbox-field">
                      <input type="checkbox" className="custom-control-input chkallexpert" id={"expertChk" + i} name={"expertChk" + i} ischecked={this.state.ischecked}
                        onChange={e => {
                          this.handleCheckboxChangeexpert(e, ele, i);
                        }} />
                      <label className="custom-control-label" htmlFor={"expertChk" + i}></label>
                    </div>
                    </td> : <td></td> }
                      <td className="">
                        <div className="hideMob">
                        <div class="table-skillset ask-expert-table-col-name">
                          {ele.profilePic !== "" ? <img src={API_URL + "/" + ele.profilePic} /> :
                            <img src={require("./../../assets/images/profile.jpg")} />}
                          {/* <NavLink to="/empProfile"><span>{ele.firstname} {ele.lastname}</span></NavLink> */}
                          <span className="textcolor" onClick={e => this.renderOnEmployee(e, ele)}>{ele.firstname} {ele.lastname}</span>
                        </div></div>
                          <div className="showMob flex-column">
                          <div className="table-skillset ask-expert-table-col-nameInMob">
                          {ele.profilePic !== "" ? <img src={API_URL + "/" + ele.profilePic} /> :
                            <img src={require("./../../assets/images/profile.jpg")} />}                          
                            <span className="textcolorInMob" onClick={e => this.renderOnEmployee(e, ele)}>{ele.firstname} {ele.lastname}</span>
                        </div>  
                          <div><b>Skillset: </b>{ele.skillname}</div>
                          <div><b>Expertise Level: </b>
                          <StarRating
                            handleRatingChangeProp={this.onChangeExpertiseLevel.bind(this)}
                            rating={ele.level} disableClick={true}>
                          </StarRating>
                          </div>
                          <div><b>Experience: </b>{ele.experience}</div>
                          <div><b>Practicing: </b>{ele.currentStatus === "Practising" ? "Yes" : "No"}</div>
                          <div><b>Last used/Since using: </b>{ele.year}</div>
                          <div><b>Dm Comment: </b>{ele.comment}</div>
                          <div>
                            <span onClick={this.addskillDiredct.bind(this, ele)} className="textcolorInMob">Add skill</span> &nbsp;&nbsp;|&nbsp;&nbsp;
                            <span onClick={this.commentskillDiredct.bind(this, ele)} className="textcolorInMob">MNGR Comment</span>
                          </div>
                        </div>
                      </td>
                      <td className="hideMob">
                        <div className="table-skillset">{ele.skillname} </div>
                      </td>
                      <td className="hideMob">
                        <div>
                          <StarRating
                            handleRatingChangeProp={this.onChangeExpertiseLevel.bind(this)}
                            rating={ele.level} disableClick={true}>
                          </StarRating>
                        </div>
                      </td>
                      <td className="hideMob">
                        <div className="table-skillset">{ele.experience}</div>
                      </td>
                      <td className="hideMob">
                        {ele.currentStatus === "Practising" ? <div className="table-skillset">Yes</div> : <div className="table-skillset">No</div>}
                      </td>

                      <td className="hideMob">
                        <div className="table-skillset"> {ele.year}</div>
                      </td>

                      <td className="hideMob">
                        <div className="table-skillset"> {ele.comment}</div>
                      </td>

                      <td className="hideMob">
                        <p onClick={this.addskillDiredct.bind(this, ele)} className="textcolor">Add skill</p>
                        <p onClick={this.commentskillDiredct.bind(this, ele)} className="textcolor">MNGR Comment</p>
                      </td>
                    </tr>
                  )
                  )) : <tr><td className="tableStyle"> No data available!</td> </tr>}
              </tbody>
            </table>
          </TabContainer>
        )}
        
        {value === 2 && (
          <TabContainer>
            <table className="table dashboard-skill-table">
              <tbody>
              <tr>
                  <td colSpan="4" className="no-border">
                    <i className="fa fa-square" aria-hidden="true" /> Skillset
                    available for Manager Approval!
                  </td>
                </tr>
                <tr className="hideMob">
                  <th width="2%">
                    <div className="custom-control custom-checkbox custom-checkbox-field">
                      <input type="checkbox" className="custom-control-input" id="interchkAll" name="interchkAll" onChange={e => {
                        this.handleAllCheckboxChangepractitioner(
                          e.target.checked,
                          pendingListintermediat
                        );
                      }} />
                      <label className="custom-control-label" htmlFor="interchkAll"></label>
                    </div>
                  </th>
                  
                  <th width="15%">EMPLOYEE NAME</th>
                  <th width="12%">SKILLSET</th>
                  <th width="10%">EXPERTISE LEVEL</th>
                  <th width="10%">EXPERIENCE</th>
                  <th width="10%">PRACTICING</th>
                  <th width="10%">LAST USED</th>
                  <th width="15%">DM COMMENT</th>
                  <th width="10%">ACTION</th>
                </tr>
                {this.props.practitionerData != undefined ? (
                  this.props.practitionerData.map((ele, i) => (
                    <tr className={ele.skillStatus === "pending" ? "pending-notation" : ""} >
                  { ele.skillStatus === "pending" ?  <td>
                        <div className="custom-control custom-checkbox custom-checkbox-field">
                          <input type="checkbox" className="custom-control-input chkallinter" id={"interChk" + i} name={"interChk" + i} onChange={e => {
                            this.handleCheckboxChangepractitioner(e, ele, i);
                          }} />
                          <label className="custom-control-label" htmlFor={"interChk" + i}></label>
                        </div>
                      </td>
                   : <td></td> }

                      <td className="">
                        <div className="hideMob">
                        <div class="table-skillset ask-expert-table-col-name">
                          {ele.profilePic !== "" ? <img src={API_URL + "/" + ele.profilePic} /> :
                            <img src={require("./../../assets/images/profile.jpg")} />}
                          {/* <NavLink to="/empProfile"><span>{ele.firstname} {ele.lastname}</span></NavLink> */}
                          <span className="textcolor" onClick={e => this.renderOnEmployee(e, ele)}>{ele.firstname} {ele.lastname}</span>
                        </div></div>
                         <div className="showMob flex-column">
                          <div className="table-skillset ask-expert-table-col-nameInMob">
                          {ele.profilePic !== "" ? <img src={API_URL + "/" + ele.profilePic} /> :
                            <img src={require("./../../assets/images/profile.jpg")} />}                          
                            <span className="textcolorInMob" onClick={e => this.renderOnEmployee(e, ele)}>{ele.firstname} {ele.lastname}</span>
                        </div>  
                          <div><b>Skillset: </b>{ele.skillname}</div>
                          <div><b>Expertise Level: </b>
                          <StarRating
                            handleRatingChangeProp={this.onChangeExpertiseLevel.bind(this)}
                            rating={ele.level} disableClick={true}>
                          </StarRating>
                          </div>
                          <div><b>Experience: </b>{ele.experience}</div>
                          <div><b>Practicing: </b>{ele.currentStatus === "Practising" ? "Yes" : "No"}</div>
                          <div><b>Last used/Since using: </b>{ele.year}</div>
                          <div><b>Dm Comment: </b>{ele.comment}</div>
                          <div>
                            <span onClick={this.addskillDiredct.bind(this, ele)} className="textcolorInMob">Add skill</span> &nbsp;&nbsp;|&nbsp;&nbsp;
                            <span onClick={this.commentskillDiredct.bind(this, ele)} className="textcolorInMob">MNGR Comment</span>
                         </div>
                        </div>
                      </td>
                      <td className="hideMob">
                        <div className="table-skillset">{ele.skillname} </div>
                      </td>
                      <td className="hideMob">
                        <div>
                          <StarRating
                            handleRatingChangeProp={this.onChangeExpertiseLevel.bind(this)}
                            rating={ele.level} disableClick={true}>
                          </StarRating>
                        </div>
                      </td>
                      <td className="hideMob">
                        <div className="table-skillset">{ele.experience}</div>
                      </td>
                      <td className="hideMob">
                        {ele.currentStatus === "Practising" ? <div className="table-skillset">Yes</div> : <div className="table-skillset">No</div>}
                      </td>

                      <td className="hideMob">
                        <div className="table-skillset"> {ele.year}</div>
                      </td>
                      <td className="hideMob">
                        <div className="table-skillset"> {ele.comment}</div>
                      </td>
                      <td className="hideMob">
                        <p onClick={this.addskillDiredct.bind(this, ele)} className="textcolor">Add skill</p>
                        <p onClick={this.commentskillDiredct.bind(this, ele)} className="textcolor">MNGR Comment</p>
                      </td>
                    </tr>
                  )
                  )) : <tr><td className="tableStyle"> No data available!</td> </tr>}
              </tbody>
            </table>
          </TabContainer>
        )}

        {value === 3 && (
          <TabContainer>
            <table className="table dashboard-skill-table">
              <tbody>
              <tr>
                  <td colSpan="4" className="no-border">
                    <i className="fa fa-square" aria-hidden="true" /> Skillset
                    available for Manager Approval!
                  </td>
                </tr>
                <tr className="hideMob">
                  <th width="2%"  >
                    <div className="custom-control custom-checkbox custom-checkbox-field">
                      <input type="checkbox" className="custom-control-input" id="novicechkAll" name="novicechkAll" onChange={e => {
                        this.handleAllCheckboxChangenovice(
                          e.target.checked,
                          pendingListnovice
                        );
                      }} />
                      <label className="custom-control-label" htmlFor="novicechkAll"></label>
                    </div>
                  </th>
                  <th width="15%">EMPLOYEE NAME</th>
                  <th width="12%">SKILLSET</th>
                  <th width="10%">EXPERTISE LEVEL</th>
                  <th width="10%">EXPERIENCE</th>
                  <th width="10%">PRACTICING</th>
                  <th width="10%">LAST USED</th>
                  <th width="15%">DM COMMENT</th>
                  <th width="10%">ACTION</th>
                </tr>
                {this.props.noViceData != undefined ? (
                  this.props.noViceData.map((ele, i) => (
                    <tr className={ele.skillStatus === "pending" ? "pending-notation" : ""}>
                      { ele.skillStatus === "pending" ?  <td>
                      <div className="custom-control custom-checkbox custom-checkbox-field">
                        <input type="checkbox" className="custom-control-input chkallnovice" id={"noviceChk" + i} name={"noviceChk" + i} onChange={e => {
                          this.handleCheckboxChangenovice(e, ele, i);
                        }} />
                        <label className="custom-control-label" htmlFor={"noviceChk" + i}></label>
                      </div>
                      </td>
                      : <td></td> }

                      <td className="">
                        <div className="hideMob">
                        <div class="table-skillset ask-expert-table-col-name">
                          {ele.profilePic !== "" ? <img src={API_URL + "/" + ele.profilePic} /> :
                            <img src={require("./../../assets/images/profile.jpg")} />}

                          {/* <NavLink to="/empProfile"><span>{ele.firstname} {ele.lastname}</span></NavLink> */}
                          <span className="textcolor" onClick={e => this.renderOnEmployee(e, ele)}>{ele.firstname} {ele.lastname}</span>
                        </div></div>
                        <div className="showMob flex-column">
                          <div className="table-skillset ask-expert-table-col-nameInMob">
                          {ele.profilePic !== "" ? <img src={API_URL + "/" + ele.profilePic} /> :
                            <img src={require("./../../assets/images/profile.jpg")} />}                          
                            <span className="textcolorInMob" onClick={e => this.renderOnEmployee(e, ele)}>{ele.firstname} {ele.lastname}</span>
                        </div>  
                          <div><b>Skillset: </b>{ele.skillname}</div>
                          <div><b>Expertise Level: </b>
                          <StarRating
                            handleRatingChangeProp={this.onChangeExpertiseLevel.bind(this)}
                            rating={ele.level} disableClick={true}>
                          </StarRating>
                          </div>
                          <div><b>Experience: </b>{ele.experience}</div>
                          <div><b>Practicing: </b>{ele.currentStatus === "Practising" ? "Yes" : "No"}</div>
                          <div><b>Last used/Since using: </b>{ele.year}</div>
                          <div><b>DM Comment: </b>{ele.comment}</div>
                          <div>
                            <span onClick={this.addskillDiredct.bind(this, ele)} className="textcolorInMob">Add skill</span> &nbsp;&nbsp;|&nbsp;&nbsp;
                            <span onClick={this.commentskillDiredct.bind(this, ele)} className="textcolorInMob">MNGR Comment</span>
                          </div>
                        </div>
                      </td>
                      <td className="hideMob">
                        <div className="table-skillset">{ele.skillname} </div>
                      </td>
                      <td className="hideMob">
                        <div>
                          <StarRating
                            handleRatingChangeProp={this.onChangeExpertiseLevel.bind(this)}
                            rating={ele.level} disableClick={true}>
                          </StarRating>
                        </div>
                      </td>
                      <td className="hideMob">
                        <div className="table-skillset">{ele.experience}</div>
                      </td>
                      <td className="hideMob">
                        {ele.currentStatus === "Practising" ? <div className="table-skillset">Yes</div> : <div className="table-skillset">No</div>}
                      </td>

                      <td className="hideMob">
                        <div className="table-skillset"> {ele.year}</div>
                      </td>
                      <td className="hideMob">
                        <div className="table-skillset"> {ele.comment}</div>
                      </td>

                      <td className="hideMob">
                        <p onClick={this.addskillDiredct.bind(this, ele)} className="textcolor">Add skill</p>
                        <p onClick={this.commentskillDiredct.bind(this, ele)} className="textcolor">MNGR Comment</p>
                      </td>
                    </tr>
                  )
                  )) : <tr><td className="tableStyle"> No data available!</td> </tr>}
              </tbody>
            </table>
          </TabContainer>
        )}
          {this.state.isModalOpen ? (
          <AddSkillDm
            modelOpen={this.state.isModalOpen}
            addDirectSkill={this.state.addDirectSkill}
            addSkillDirect={this.addSkillDirect}
            close={this.close.bind(this)}
          />
        ) : null}
        {this.state.isComentModalOpen ? (
          <CommentComponent
            modelOpen={this.state.isComentModalOpen}
            skillData={this.state.skillData}
            sendCommentToEmployee={this.sendCommentToEmployee}
            closeModal={this.closeCommentBox.bind(this)}
          />
        ) : null}
      </div>
    );
  }
}

MydirectsTabs.propTypes = {
  classes: PropTypes.object.isRequired,
  dispatch: PropTypes.func.isRequired
};

export default withStyles(styles)(withRouter(MydirectsTabs));
