// this component will display approved skill list in tab view on dashboard.
// it will display skills according to Expert , Intermediat and  Novice

import React, { Component } from "react";
import SkillTableRow from "./skilltablerow";

class ApprovedComponent extends Component {
  openModel = e => {
    return this.props.getselectedrow(e);
  };

  onDeleteClick = e => {
    return this.props.getdeletedrow(e);
  };

  render() {
    return this.props.approvedList.map((ele, i) => (
      <SkillTableRow
        approvedData={ele}
        key={i}
        onrowclick={this.openModel}
        ondeleteclick={this.onDeleteClick}
      />
    ));
  }
}

export default ApprovedComponent;
