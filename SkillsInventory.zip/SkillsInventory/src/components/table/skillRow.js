import React, { Component } from "react";
class SkillRow extends Component {
  render() {
    return (
      <tr>
        {Object.values(this.props.row).map((ele, i) => <td key={i}>{ele}</td>)}
      </tr>
    );
  }
}

export default SkillRow;
