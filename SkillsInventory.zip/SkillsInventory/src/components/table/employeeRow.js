import React, { Component, Fragment } from "react";
import './operatorRow'
import { hidden } from "ansi-colors";

class EmployeeRow extends Component {
  constructor(props) {
    super(props);
  }
  state ={
    skilldetails:'none',
    empdta:""
  }
  coldata = () =>{
    this.setState({
      empdta:this.props.row
    })
    if(this.state.skilldetails === 'none'){
      this.setState({skilldetails:''})
    }
    else{
      this.setState({skilldetails:'none'})
    }
  }
  render() {
    return (
      <Fragment>
      <tr class="clickable" data-toggle="collapse" data-target="#group-of-rows-1"  aria-controls="group-of-rows-1" onClick={this.coldata}>
        {Object.values(this.props.row).map((ele, i) => (
          <td key={i}>{ele}</td> 
        ))}
      </tr>  
      <tr style={{display:this.state.skilldetails}} >
        Username : {this.state.empdta.username}
        Skillname :  {this.state.empdta.skillname}
        Level : {this.state.empdta.level}
        CurrentStatus : {this.state.empdta.currentStatus}
        Year : {this.state.empdta.year}
      </tr>
      </Fragment>
    );
  }
}

export default EmployeeRow;
