import React, { Component } from "react";
import "./starRating.css"
import ReactHover from 'react-hover'

const optionsCursorTrueWithMargin = {
    followCursor: true,
    shiftX: 20,
    shiftY: 0
}
class StarRating extends Component {
    constructor(props) {
        super(props);
        this.state = {
            rating: this.props ? this.props.rating ? this.props.rating : "Novice" : "Novice",
            disableClick: this.props ? this.props.disableClick ? this.props.disableClick : null : null
        }
        this.classes = ["fa fa-star fa-lg Novice", "fa fa-star fa-lg", "fa fa-star fa-lg"];
        this.skillLevels = ["Novice", "Practitioner", "Expert"];
        if (this.props) {
            if (this.props.rating) {
                this.handleRatingLoad(this.props.rating)
            }
        }
    }

    handleRatingLoad(rating) {
        this.handleRating(rating);
    }

    handleRating(incommingRating) {
        if (incommingRating === "Novice") {
            this.classes[0] = `fa fa-star fa-lg Novice`;
            this.classes[1] = `fa fa-star fa-lg`;
            this.classes[2] = `fa fa-star fa-lg`
        } else if (incommingRating === "Practitioner") {
            this.classes[0] = `fa fa-star fa-lg Practitioner`;
            this.classes[1] = `fa fa-star fa-lg Practitioner`;
            this.classes[2] = `fa fa-star fa-lg`;
        } else {
            this.classes[0] = `fa fa-star fa-lg Expert`;
            this.classes[1] = `fa fa-star fa-lg Expert`;
            this.classes[2] = `fa fa-star fa-lg Expert`;
        }
        this.setState({ rating: incommingRating });
        this.props.handleRatingChangeProp(incommingRating);
    }
    render() {
        let disableclick = false;
        if (this.state.disableClick !== null) {
            disableclick = true;
        }
        return (
            <div className="starcontainer">
                {this.skillLevels.map((skillLevel, i) => {
                    return this.state.disableClick ? (<i id={(this.props.name + i)} key={skillLevel} className={this.classes[i]} aria-hidden="true"></i>) : (<i id={(this.props.name + i)} key={skillLevel} className={this.classes[i]} aria-hidden="true" onClick={this.handleRating.bind(this, skillLevel)}></i>);
                })}
                <p>{this.state.rating}</p>
            </div>);
    }
}

export default StarRating;