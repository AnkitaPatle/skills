import routingConfig from "./routingConfig";
import Dashboard from "./containers/dashboard/dashboard";
import LogoutComponent from "./containers/logout/logout";
import ProfileComponent from "./containers/profile/profile";
import SkillsComponent from "./containers/skill/skill";
import Askexpert from './containers/askexpert/askexpert';
import PastqueryComponent from './containers/askexpert/pastqueries';
import EmployeeComponent from "./containers/employee/employee";
import SkillClusterComponent from "./containers/skillcluster/skillcluster";
import MapskillsComponent from "./containers/skillcluster/mapskills/mapskills";
import ApproveSkillComponent from "./containers/manager/approveskill";
import AddDirectSkillComponent from './containers/manager/adddirectskill/adddirectskill';
import AssignroleComponent from "./containers/admin/role/assignrole";
import ChangepasswordComponent from "./containers/admin/changepassword/changepassword";

export const getPathsFromCurrentRole = () => {
  const role = sessionStorage.getItem("role");
  if (!role) {
    return []
  }
    
  const paths = routingConfig[role];
  if (!paths) {
    return [];
  }
  return paths;
};
