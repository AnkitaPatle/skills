import React, { Component } from "react";
import { NavLink } from "react-router-dom";
import { getPathsFromCurrentRole } from "./Utils";
import "./assets/css/common.css";

const logo = {
  padding: "20px 20px 0 20px",
  color: "#c6c7c7",
  fontSize: "20px"
};

const navbar = {
  background: "#252526",
  height: "100%"
};

class Routing extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isEmployee: false,
      isManager: false,
      isCapdev: false,
      isAdmin: false
    };

    this.role = sessionStorage.getItem("role");
    if (this.role == "Employee") {
      this.state.isEmployee = true;
    } else if (this.role == "DM") {
      this.state.isManager = true;
      this.state.isEmployee = true;
    } else if (this.role == "Capdev") {
      this.state.isCapdev = true;
      this.state.isEmployee = true;
    } else {
      this.state.isAdmin = true;
    }
  }

  render() {
    return (
      <div style={navbar}>
        <div>
          <nav>
            <ul className="navbar-nav">
              {getPathsFromCurrentRole().map(({ path, name, idx }) => (
                <li className="nav-item" key={idx}>
                  <NavLink className="nav-link" to={path} key={idx}>
                    {name}
                  </NavLink>
                </li>
              ))}
            </ul>
          </nav>
        </div>
      </div>
    );
  }
}

export default Routing;
