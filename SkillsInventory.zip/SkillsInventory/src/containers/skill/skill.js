// This is main skill component which contains add skill and display skill components as child components.

import React, { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import Routing from "../../routing";
import Header from "../../components/header/header";
import * as actions from "./skillActions";
import AddSkillTableComponent from "./addskillTable";
import "./skill.css";
import { Redirect } from "react-router-dom";

const minOffset = 0;
const maxOffset = 20;
const thisYear = new Date().getFullYear();

class SkillsComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      skillName: "",
      expertiseLevel: "",
      currentStatus: "",
      thisYear: thisYear,
      selectedYear: thisYear,
      message: ""
    };
  }

  submitAllSkillInfo(e) {
    const employeeSkill = {
      skillName: this.state.skillName,
      expertiseLevel: this.state.expertiseLevel,
      currentStatus: this.state.currentStatus,
      year: this.state.selectedYear
    };

    const { dispatch } = this.props;
    dispatch(actions.createSkills(employeeSkill));
    this.clearAllFields();
  }

  clearAllFields = () => {
    this.setState({ skillName: "" });
    this.setState({ expertiseLevel: "" });
    this.setState({ currentStatus: "" });
    this.setState({ selectedYear: thisYear });
  };

  onChangeSkillName(e) {
    this.setState({ skillName: e.target.value });
    this.setState({ message: "" });
    const { dispatch } = this.props;
    dispatch(actions.ChangeStatus());
  }
  onChangeExpertiseLevel(e) {
    this.setState({ expertiseLevel: e.target.value });
    this.setState({ message: "" });
  }
  onChangeCurrentStatus(e) {
    this.setState({ currentStatus: e.target.value });
    this.setState({ message: "" });
  }
  onChangeSelectedYear(e) {
    this.setState({ selectedYear: e.target.value });
    this.setState({ message: "" });
  }

  render() {
    if (!localStorage.getItem("token") ) {
      return <Redirect to="/" />;
    }
    const { skills } = this.props;
    const { thisYear, selectedYear } = this.state;
    const options = [];

    for (let i = minOffset; i <= maxOffset; i++) {
      const year = thisYear - i;
      options.push(<option value={year}>{year}</option>);
    }
    return (
      <div>
        <div className="col-md-12">
          <div>
            <Header />
          </div>
          <div className="row">
            <div className="col-md-12 dashboard-container">
              <h1 className="dashboard-page-title">Add Skills</h1>
              <AddSkillTableComponent />
            </div>
          </div>
        </div>
      </div>
    );
  }
}

SkillsComponent.propTypes = {
  skills: PropTypes.object.isRequired,
  dispatch: PropTypes.func.isRequired
};

const mapStateToProps = state => {
  let skills = {};
  if (state.skillReducer.skills !== undefined) {
    skills = state.skillReducer;
    return skills;
  } else {
    return { skills };
  }
};

export default connect(mapStateToProps)(SkillsComponent);
