import React, { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import * as actions from "./skillActions";
import "./skill.css";

class DisplayskillsComponent extends Component {
  state = {};

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch(actions.getAllSkills());
  }

  render() {
    return (
      <div>
        <div className="sectiontitle">
          <h2> Your Skills </h2>
        </div>
        <div className="row">
          <div className="col-md-12 cardrow">
            {this.props.employeeSkills.map((prd, idx) => (
              <div key={idx} className="card col-md-2">
                <div className="buttons">
                  <label className="colormix">{prd.skillStatus}</label>
                  <button className="btn-close">
                    <i className="fa fa-trash-o"> </i>
                  </button>
                  <button className="btn-edit">
                    <i className="icon icon-edit" aria-hidden="true" />
                  </button>
                </div>
                <div className="container">
                  <center>
                    <span className="skillname">{prd.skillname}</span>{" "}
                  </center>
                  <br />
                  <span className="level">{prd.level}</span>
                  <span className="pullright">{prd.year}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }
}

DisplayskillsComponent.propTypes = {
  getAllEmployeeList: PropTypes.object.isRequired,
  dispatch: PropTypes.func.isRequired
};

const mapStateToProps = state => {
  return {
    employeeSkills: state.skillReducer.employeeSkills || []
  };
};

export default connect(mapStateToProps)(DisplayskillsComponent);
