import * as actionTypes from "./dashboardActionTypes";
const dashboardReducer = (state = {}, action) => {
  switch (action.type) {
    case actionTypes.FETCH_SKILL_BY_LEVEL:
      return Object.assign({}, state, {
        employeeSkillsByLevel: action.payload
      });
    default:
      return state;
  }
};
export default dashboardReducer;
