import React, { Component } from 'react';
// import Modal from "react-modal";
import Modal from 'react-bootstrap/Modal';
import './askexprt.css';
import StarRating from './../../components/starRating/starRating';
import { blockParams } from 'handlebars';
import sendImage from '../../assets/images/send.jpg';
import { toastr } from "react-redux-toastr";
import {API_URL} from './../../config';

import like from '../../assets/images/like.png';
import neutral from '../../assets/images/neutral.png';
import dislike from '../../assets/images/dislike.png';

import likeFill from '../../assets/images/like-fill.png'
import neutralFill from '../../assets/images/neutral-fill.png'
import dislikeFill from '../../assets/images/dislike-fill.png'

const minOffset = 0;
const maxOffset = 20;
const thisYear = new Date().getFullYear();

class PastQueriesScreenNew extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isModelOpen: false,
      selectedRow: "",
      disable:false,
      modalIsOpen: this.props.modelOpen ? true : false,
      skillName: this.props.selectedData
        ? this.props.selectedData.skillname
        : "",
      title: this.props.title,
      query: "",
      queryObj: [],

      noviceImage: dislike,
      practitionerImage: neutral,
      expertImage: like,

      noviceImg: dislike,
      practitionerImg: neutral,
      expertImg: like,
      
      noviceColorImage: dislikeFill,
      practitionerColorImage: neutralFill,
      expertColorImage: likeFill,
      img: null,

       classes: this.props.empdata ?
        this.props.empdata.rating ?
          this.props.empdata.rating == 'No'
            ? [`${dislike} Novice`] :
            this.props.empdata.rating == 'Somewhat' ?
              [`${neutral} Practitioner`] :
              this.props.empdata.rating == 'Yes' ?
                [`${like} Expert`] :
                [`${dislike} Novice`, `${neutral}`, `${like}`] :
          [`${dislike} Novice`, `${neutral}`, `${like}`] :
        [`${dislike} Novice`, `${neutral}`, `${like}`]

      
    };
    this.ratingExpert = "No";
  }

  onChangeSkillName(e) {
    this.setState({ skillName: e.target.value });
    this.setState({ expertiseLevel: e.target.value });
    this.setState({ message: "" });
  }

  onChangeExpertiseLevel(e) {
    this.setState({ expertiseLevel: e.target.value });
    this.setState({ message: "" });
  }
  onChangeCurrentStatus(e) {
    this.setState({ currentStatus: e.target.value });
    this.setState({ message: "" });
  }
  onChangeSelectedYear(e) {
    this.setState({ selectedYear: e.target.value });
    this.setState({ message: "" });
  }

  openModal() {
    this.setState({ modalIsOpen: true });
  }

  ratingCheck = (rating) => {
    this.setState({ ratingExpert: rating });
  }
  getquery = (e) => {
    this.setState({
      query: e.target.value
    })
  }
  sendQueryToexpertSave = () => {
    this.setState({disable:true})
    if (this.state.query !== "" && this.state.query.trim())
    {
      const queryval = this.props.empdata.query;
      var obj = new Object();
      obj.data = this.props.empdata;
      obj.data.query = this.state.query;
      obj.data.querystat = this.props.empdata.querystat;
      obj.data.ratingExpert = this.ratingExpert;
      obj.data.queryvalidation = queryval;
      this.state.queryObj.push(obj);
      return this.props.sendQueryToexpert(this.state.queryObj);     
    } else
    {
      toastr.warning("Warning!", "Please Enter Comment for An Expert!", {
        showCloseButton: false,
        timeOut: 3000
      });
    }
    this.setState({disable:false})
  }
  sendQueryToexpert = () => {
    if (this.state.query !== "" && this.state.query.trim())
    {
      const queryval = this.props.empdata.query;
      var obj = new Object();
      obj.data = this.props.empdata;
      obj.data.query = this.state.query;
      obj.data.querystat = this.props.empdata.querystat;
      obj.data.ratingExpert = this.ratingExpert;
      obj.data.queryvalidation = queryval;
      this.state.queryObj.push(obj);
      return this.props.sendQueryToexpert(this.state.queryObj);
    } else
    {
      toastr.warning("Warning!", "Please ask your query!", {
        showCloseButton: false,
        timeOut: 3000
      });
    }
  }
handleRating = (incommingRating) => {
    if (incommingRating === "No")
    {  

      this.setState({ noviceImage: this.state.noviceColorImage });
      this.setState({ practitionerImage: this.state.practitionerImg  });
      this.setState({ expertImage: this.state.expertImg });      
    } else if (incommingRating === "Somewhat")
    {
     
      this.setState({ noviceImage: this.state.noviceImg });
      this.setState({ practitionerImage: this.state.practitionerColorImage });      
      this.setState({ expertImage: this.state.expertImg });
    } else if (incommingRating === "Yes")
    {     
       
      this.setState({ noviceImage: this.state.noviceImg });
      this.setState({ practitionerImage: this.state.practitionerImg  });
      this.setState({ expertImage: this.state.expertColorImage });
    }
    this.ratingExpert = incommingRating;
  }
 
  render() {
    
    const skillname = this.props.empdata.skillname && this.props.empdata.skillname.charAt(0).toUpperCase() + this.props.empdata.skillname.slice(1);
    const query = this.props.empdata.query && this.props.empdata.query.charAt(0).toUpperCase() + this.props.empdata.query.slice(1);
    const comment = this.props.empdata.comment && this.props.empdata.comment.charAt(0).toUpperCase() + this.props.empdata.comment.slice(1);
    const empdata = this.props.empdata;
    let email = '';
    empdata.managers && empdata.managers !== 0 ?
      email = (empdata.managers) :
      email = '-. @mail.com';
      console.log( email, " empdata.managers");
    return (
      <Modal backdrop="static"
        show={this.state.modalIsOpen}
        onHide={this.props.closeModal.bind(this)}
        centered
        className="ask-expert-modal"
      >
        <Modal.Header closeButton className="mx-3 px-0">
          <Modal.Title>{this.state.title}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="row">
            <div className="col-md-12">
              <div className="d-flex ask-expert-modal-user-info">
                <div className="ask-expert-modal-user-info-left">
                {empdata.profilePic === "" || empdata.profilePic === undefined ? <img
                src={require("../../assets/images/profile.jpg")}
                className="img-fluid rounded-circle"
              /> : <img
                src={API_URL + "/" + empdata.profilePic}
                className="img-fluid rounded-circle"
              />}
                  <div className="ask-expert-modal-user-info-summary">
                    <div >
                      <div>
                        <span className="ask-expert-modal-user-info-name"> {empdata.firstname} {empdata.lastname} </span>
                      </div>
                      <div className="summary-info-row">
                        <span className="ask-expert-modal-user-info-naame"  style={{fontSize:"14px"}}>Designation : </span>                     
                        <span className="ask-expert-modal-user-info-skill"  style={{fontSize:"14px"}}> {empdata.designation}</span>
                      </div>
                      <div className="summary-info-row">
                        <span className="ask-expert-modal-user-info-naame"  style={{fontSize:"14px"}}>Delivery Manager : </span>
                        <span className="ask-expert-modal-user-info-skill"  style={{fontSize:"14px"}}> {email !== "-"?email.split('.')[0] + ' ' + email.split('.')[1].split('@')[0]:"-"}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="ask-expert-modal-user-info-right">
                  <p className="ask-expert-modal-user-info-position">{skillname}</p>
                  {/* <StarRating 
                  name={empdata.firstname + empdata.lastname} 
                  handleRatingChangeProp={this.ratingCheck.bind(this)} 
                  rating={empdata.level} 
                  disableClick={true}>
                  </StarRating> */}
                  
                          <StarRating
                              name={empdata.firstname + empdata.lastname}
                              handleRatingChangeProp={this.ratingCheck.bind(this)}
                              rating={empdata.level === "FPractitioner" ?empdata.level.slice(1):empdata.level}
                              disableClick={true}
                            ></StarRating>
                </div>
              </div>
              <hr />

              {this.props.empdata.status === "S" ?
                <>
                  <div className="pt-3 d-flex">
                    <span className="rate-review-label">Query - </span>
                    <span className="rate-review-query">{query}</span>
                  </div>
                  <div className="pt-3 d-flex">
                    <span className="rate-review-label">Resolved -</span>
                    <span className="starcontainer">
                      <span><img src={this.state.noviceImage} alt="dislike" onClick={this.handleRating.bind(this, 'No')} /> No </span>&nbsp;&nbsp;&nbsp;
                      <span><img src={this.state.practitionerImage} alt="neutral" onClick={this.handleRating.bind(this, 'Somewhat')} /> Somewhat </span>&nbsp;&nbsp;&nbsp;
                      <span><img src={this.state.expertImage} alt="like" onClick={this.handleRating.bind(this, 'Yes')} /> Yes </span>
                    </span>
                  </div>
                </>
                : null
              }
              {this.props.empdata.status === "C" ?
                <>
                  <div className="pt-3 d-flex">
                    <span className="rate-review-label">Query - </span> <span className="rate-review-query">{query}</span>
                  </div>
                  <div className="pt-3 d-flex">
                    <span className="rate-review-label">Resolved - </span> {this.props.empdata.ratingExpert}
                    <span className="starcontainer rate-review-query">
                       {this.props.empdata.rating === "No" ? <span>
                                          <img src={this.state.noviceColorImage} alt="dislike" />&nbsp;
                                           {this.props.empdata.rating}</span>
                                          : this.props.empdata.rating === "Somewhat" ? <span>
                                            <img src={this.state.practitionerColorImage} alt="neutral" />&nbsp;
                                               {this.props.empdata.rating}</span>
                                            : this.props.empdata.rating === "Yes" ? <span>
                                              <img src={this.state.expertColorImage} alt="like" />&nbsp;
                                                {this.props.empdata.rating}</span>
                                              : null}
                      
                    </span>
                  </div>
                  <div className="pt-3 d-flex">
                    <span className="rate-review-label">Comment - </span>
                    <span className="rate-review-query">{comment}</span>
                  </div>
                </> : null
              }
              {
                this.props.empdata.status === "S" ? (
                  <div className="mt-3">
                    <label htmlFor="query-comment" className="ask-expert-modal-label"> Please write your comment here: </label>
                    <textarea class="form-control" rows="3" id="query-comment" onChange={(e) => this.getquery(e)} maxLength="250"></textarea>
                  </div>
                ) :
                  this.props.empdata.status === "C" ? null : (
                    <div className="mt-3">
                      <label htmlFor="query-details" className="ask-expert-modal-label"> Please Type your query details here </label>
                      <textarea class="form-control" rows="3" id="query-details" onChange={(e) => this.getquery(e)} maxLength="250"></textarea>
                    </div>)
              }
            </div>
          </div>
        </Modal.Body>
        {
          this.props.empdata.status && this.props.empdata.status === "S" ?
            <Modal.Footer>
              <button
                className="ask-expert-action-cancel"
                onClick={this.props.closeModal.bind(this)}>
                Cancel
          </button>
              <button
                className="ask-expert-action-save-ask"
                onClick={this.sendQueryToexpertSave}
                disabled = {this.state.disable}
              >
                Save
          </button>
            </Modal.Footer>
            : this.props.empdata.status !== "S" && this.props.empdata.status !== "C" ?
              <Modal.Footer>
                <button
                  className="ask-expert-action-cancel"
                  onClick={this.props.closeModal.bind(this)}>
                  Cancel
          </button>
                <button
                  className="ask-expert-action-save"
                  onClick={this.sendQueryToexpert}
                >
                  Ask
          </button>
              </Modal.Footer> : null
        } 
      </Modal>
    )
  }
}

export default PastQueriesScreenNew;