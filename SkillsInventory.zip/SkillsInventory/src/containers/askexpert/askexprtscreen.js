import React, { Component } from 'react';
import Modal from 'react-bootstrap/Modal';
import './askexprt.css';
import StarRating from './../../components/starRating/starRating';
import { blockParams } from 'handlebars';
import sendImage from '../../assets/images/send.jpg';
import { toastr } from "react-redux-toastr";

const minOffset = 0;
const maxOffset = 20;
const thisYear = new Date().getFullYear();

class AskExprtScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isModelOpen: false,
      selectedRow: "",
      modalIsOpen: this.props.modelOpen ? true : false,
      skillName: this.props.selectedData
        ? this.props.selectedData.skillname
        : "",
      title: this.props.title,
      query: "",
      queryObj: [],
      classes: this.props.empdata ?
        this.props.empdata.rating ?
          this.props.empdata.rating == 'No'
            ? ["fa fa-star fa-lg Novice"] :
            this.props.empdata.rating == 'Somewhat' ?
              ["fa fa-star fa-lg Practitioner"] :
              this.props.empdata.rating == 'Yes' ?
                ["fa fa-star fa-lg Expert"] :
                ["fa fa-star fa-lg Novice", "fa fa-star fa-lg", "fa fa-star fa-lg"] :
          ["fa fa-star fa-lg Novice", "fa fa-star fa-lg", "fa fa-star fa-lg"] :
        ["fa fa-star fa-lg Novice", "fa fa-star fa-lg", "fa fa-star fa-lg"]
    };
    this.ratingExpert = "No";
  }

  onChangeSkillName(e) {
    this.setState({ skillName: e.target.value });
    this.setState({ expertiseLevel: e.target.value });
    this.setState({ message: "" });
  }

  onChangeExpertiseLevel(e) {
    this.setState({ expertiseLevel: e.target.value });
    this.setState({ message: "" });
  }
  onChangeCurrentStatus(e) {
    this.setState({ currentStatus: e.target.value });
    this.setState({ message: "" });
  }
  onChangeSelectedYear(e) {
    this.setState({ selectedYear: e.target.value });
    this.setState({ message: "" });
  }

  openModal() {
    this.setState({ modalIsOpen: true });
  }

  ratingCheck = (rating) => {
    this.setState({ ratingExpert: rating });
  }
  getquery = (e) => {
    this.setState({
      query: e.target.value
    })
  }
  sendQueryToexpertSave = () => {
    if (this.state.query !== "" && this.state.query.trim())
    {
      const queryval = this.props.empdata.query;
      var obj = new Object();
      obj.data = this.props.empdata;
      obj.data.query = this.state.query;
      obj.data.querystat = this.props.empdata.querystat;
      obj.data.ratingExpert = this.ratingExpert;
      obj.data.queryvalidation = queryval;
      this.state.queryObj.push(obj);
      return this.props.sendQueryToexpert(this.state.queryObj);
    } else
    {
      toastr.warning("Warning!", "Please Write your comment!", {
        showCloseButton: false,
        timeOut: 3000
      });
    }
  }
  sendQueryToexpert = () => {
    if (this.state.query !== "" && this.state.query.trim())
    {
      const queryval = this.props.empdata.query;
      var obj = new Object();
      obj.data = this.props.empdata;
      obj.data.query = this.state.query;
      obj.data.querystat = this.props.empdata.querystat;
      obj.data.ratingExpert = this.ratingExpert;
      obj.data.queryvalidation = queryval;
      this.state.queryObj.push(obj);
      return this.props.sendQueryToexpert(this.state.queryObj);
    } else
    {
      toastr.warning("Warning!", "Please ask your query!", {
        showCloseButton: false,
        timeOut: 3000
      });
    }
  }
  handleRating = (incommingRating) => {
    if (incommingRating === "No")
    {
      let classarray = Object.assign([], this.state.classes);
      classarray[0] = `fa fa-star fa-lg Novice`;
      classarray[1] = `fa fa-star fa-lg`;
      classarray[2] = `fa fa-star fa-lg`;
      this.setState({ classes: classarray });
    } else if (incommingRating === "Somewhat")
    {
      let classarray = Object.assign([], this.state.classes);
      classarray[0] = `fa fa-star fa-lg Practitioner`;
      classarray[1] = `fa fa-star fa-lg Practitioner`;
      classarray[2] = `fa fa-star fa-lg`;
      this.setState({ classes: classarray });
    } else
    {
      let classarray = Object.assign([], this.state.classes);
      classarray[0] = `fa fa-star fa-lg Expert`;
      classarray[1] = `fa fa-star fa-lg Expert`;
      classarray[2] = `fa fa-star fa-lg Expert`;
      this.setState({ classes: classarray });
    }
    this.ratingExpert = incommingRating;
  }
 
  render() {
    const skillname = this.props.empdata.skillname && this.props.empdata.skillname.charAt(0).toUpperCase() + this.props.empdata.skillname.slice(1);
    const query = this.props.empdata.query && this.props.empdata.query.charAt(0).toUpperCase() + this.props.empdata.query.slice(1);
    const comment = this.props.empdata.comment && this.props.empdata.comment.charAt(0).toUpperCase() + this.props.empdata.comment.slice(1);
    const empdata = this.props.empdata;
    
    let email = '';
    empdata.managers && empdata.managers !== 0 ?
      email = (empdata.managers.toUpperCase()) :
      email = '-. @mail.com';

    return (
      <Modal
        show={this.state.modalIsOpen}
        onHide={this.props.closeModal.bind(this)}
        centered
        className="ask-expert-modal"
      >
        <Modal.Header closeButton className="mx-3 px-0">
          <Modal.Title>{this.state.title}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="row">
            <div className="col-md-12">

              <div className="d-flex ask-expert-modal-user-info">
                <div className="ask-expert-modal-user-info-left">
                  <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS6vDzm-UO315otGPTr_cWILvmR8-5VzLy3-IhDpc4h0V2LEYNz&s" />
                  <div className="ask-expert-modal-user-info-summary">
                    <div >
                      <div>
                        <span className="ask-expert-modal-user-info-name"> {empdata.firstname} {empdata.lastname} </span>
                        <span className="ask-expert-modal-user-info-skill"> - {empdata.designation}</span>
                      </div>
                      <div>
                        <span className="ask-expert-modal-user-info-naame">Delivery Manager - </span>
                        <span className="ask-expert-modal-user-info-skill"> {email.split('.')[0] + ' ' + email.split('.')[1].split('@')[0]}</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="ask-expert-modal-user-info-right">
                  <p className="ask-expert-modal-user-info-position">{skillname}</p>
                  <StarRating name={empdata.firstname + empdata.lastname} handleRatingChangeProp={this.ratingCheck.bind(this)} rating={empdata.level} disableClick={true}></StarRating>
                </div>
              </div>
              <hr />
              {this.props.empdata.status === "S" ?
                <>
                  <div className="pt-3 d-flex">
                    <span className="rate-review-label">Query - </span>
                    <span className="rate-review-query">{query}</span>
                  </div>
                  <div className="pt-3 d-flex">
                    <span className="rate-review-label">Resolved -</span>
                    <span className="starcontainer">
                      <span><i aria-hidden="true" className={this.state.classes[0]} onClick={this.handleRating.bind(this, 'No')} ></i>No </span>&nbsp;&nbsp;&nbsp;
                      <span><i aria-hidden="true" className={this.state.classes[1]} onClick={this.handleRating.bind(this, 'Somewhat')} ></i>Somewhat </span>&nbsp;&nbsp;&nbsp;
                      <span><i aria-hidden="true" className={this.state.classes[2]} onClick={this.handleRating.bind(this, 'Yes')} ></i>Yes </span>
                    </span>
                  </div>
                </>
                : null
              }
              {this.props.empdata.status === "C" ?
                <>
                  <div className="pt-3 d-flex">
                    <span className="rate-review-label">Query - </span> <span className="rate-review-query">{query}</span>
                  </div>
                  <div className="pt-3 d-flex">
                    <span className="rate-review-label">Resolved - </span> {this.props.empdata.ratingExpert}
                    <span className="starcontainer rate-review-query">
                      <span><i aria-hidden="true" className={this.state.classes[0]} ></i>{this.props.empdata.rating}</span>
                    </span>
                  </div>
                  <div className="pt-3 d-flex">
                    <span className="rate-review-label">Comment - </span>
                    <span className="rate-review-query">{comment}</span>
                  </div>
                </> : null
              }
              {
                this.props.empdata.status === "S" ? (
                  <div className="mt-3">
                    <label htmlFor="query-comment" className="ask-expert-modal-label"> Please write your comment here </label>
                    <textarea class="form-control" rows="3" id="query-comment" onChange={(e) => this.getquery(e)} maxLength="250"></textarea>
                  </div>
                ) :
                  this.props.empdata.status === "C" ? null : (
                    <div className="mt-3">
                      <label htmlFor="query-details" className="ask-expert-modal-label"> Please Type your query details here </label>
                      <textarea class="form-control" rows="3" id="query-details" onChange={(e) => this.getquery(e)} maxLength="250"></textarea>
                    </div>)
              }
            </div>
          </div>
        </Modal.Body>
        {
          this.props.empdata.status && this.props.empdata.status === "S" ?
            <Modal.Footer>
              <button
                className="ask-expert-action-cancel"
                onClick={this.props.closeModal.bind(this)}>
                Cancel
          </button>
              <button
                className="ask-expert-action-save"
                onClick={this.sendQueryToexpertSave}
              >
                Save
          </button>
            </Modal.Footer>
            : this.props.empdata.status !== "S" && this.props.empdata.status !== "C" ?
              <Modal.Footer>
                <button
                  className="ask-expert-action-cancel"
                  onClick={this.props.closeModal.bind(this)}>
                  Cancel
          </button>
                <button
                  className="ask-expert-action-save"
                  onClick={this.sendQueryToexpert}
                >
                  Ask
          </button>
              </Modal.Footer> : null
        } 
      </Modal>
    )
  }
}

export default AskExprtScreen;