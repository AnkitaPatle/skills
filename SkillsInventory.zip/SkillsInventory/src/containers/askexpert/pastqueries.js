import React, { Component, Fragment } from 'react';
import AskExprtScreen from './askexprtscreen';
import * as actions from "./askExpertAction";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import askExpertReducer from './askExpertReducer';
import { MDBDataTable, MDBInput } from "mdbreact";
import StarRating from './../../components/starRating/starRating';
import './askexprt.css';
import Header from "./../../components/header/header";
import Routing from "./../../routing";
import Autosuggest from "react-autosuggest";
import * as skillsactions from "./../skill/skillActions";
import { toastr } from "react-redux-toastr";
import { API_URL } from './../../config';
import { Redirect } from "react-router-dom";
import Moment from 'react-moment';

let suggestedskills = [];
const getSuggestions = value => {
  const inputValue = value.trim();
  const inputLength = inputValue.length;
  return inputLength === 0
    ? []
    : suggestedskills.filter(
      lang => lang.name.toLowerCase().slice(0, inputLength) === inputValue
    );
};

const getSuggestionValue = suggestion => suggestion.name;
const renderSuggestion = suggestion => <div>{suggestion.name}</div>;
class Askexpert extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isModelOpen: false,
      dtaarr: [
        {
          srno: "",
          empname: "",
          delmanager: "",
          role: "",
          exprtlevel: "",
          query: "",
        }
      ],
      mainarr: [
        {
          srno: "1",
          empname: "Samrat Dhopte",
          delmanager: "Anita Deshpande",
          role: "Associate Design Lead",
          exprtlevel: "*** Expert"
        }
      ],
      srchval: "",
      empdta: "",
      skilldetails: 'none',
      value: "",
      suggestions: [],
      skillName: "",
      modalTitle: ""
    }
  }

  componentDidMount = (e) => {
    const { dispatch } = this.props;
    dispatch(actions.GetsendQuery(this.state.srchval));
  }

  openModel = (data, title) => {
    this.setState({
      dtaarr: data
    })
    this.setState({
      isModelOpen: true,
      modalTitle: title
    });
  };
  close = () => {
    this.setState({
      isModelOpen: false
    })
  }
  getsrchval = (e) => {
    this.setState({
      srchval: e.target.value
    })
  }
  GetsendQuery = (e) => {
    if (this.state.value !== "" && this.state.value.trim())
    {
      const { dispatch } = this.props;
      dispatch(actions.GetsendQuery(this.state.srchval)).then((res) =>{
        if(this.props.querysenddata.length === 0)
        {
          toastr.warning("Warning!", "No Data Available!", { 
            showCloseButton: false,
            timeOut: 3000
          });
        }
      });
    } else
    {
      toastr.warning("Warning!", "Please enter skill name!", {
        showCloseButton: false,
        timeOut: 3000
      });
    }
  }
  ratingCheck = (e) => {
  }
  sendQueryToexpert = (query) => {
    const { dispatch } = this.props;
    dispatch(actions.sendQueryToExpert(query));
    this.setState({
      isModelOpen: false
    });
  }

  myFunction = (index) => {
    var dots = document.getElementById("dots" + index);
    var moreText = document.getElementById("more" + index);
    var btnText = document.getElementById("myBtn" + index);
    if (dots.style.display === "none")
    {
      dots.style.display = "inline";
      btnText.innerHTML = "...Read more";
      moreText.style.display = "none";
    } else
    {
      if (btnText.innerHTML.length < 110)
      {
        dots.style.display = "none";
        btnText.innerHTML = "...Read less";
        moreText.style.display = "inline";
      }
    }
  }

  onSuggestionsFetchRequested = ({ value }) => {
    if (value.length <= 60)
    {
      this.setState({
        srchval: value,
        suggestions: getSuggestions(value)
      })
    } else
    {
      this.setState({
        srchval: value.slice(0, 60),
        value: value.slice(0, 60),
        suggestions: getSuggestions(value.slice(0, 60))
      })
    }
  };

  onSuggestionsClearRequested = () => {
    this.setState({
      suggestions: []
    });
  };
  onChange = (event, { newValue }) => {
    this.setState({ srchval: event.target.innerText });
    this.setState({ value: newValue });
    const { dispatch } = this.props;
    const skillname = { skillname: event.target.innerText };
    dispatch(skillsactions.getAllSkillsFromCluster(skillname));
  };

  onEnterKeyPress = e => {
    if (e.key === "Enter")
    {
      this.GetsendQuery(e);
    }
  };

  render() {
  if (!localStorage.getItem("token")) {
      return <Redirect to="/" />;
    }
    const empdata = this.props.allEmployeeData;
    const empdtacount = this.props.allEmployeeData.length;
    suggestedskills = this.props.allskills;
    const { value, suggestions } = this.state;
    const inputProps = {
      placeholder: "Search by Skill (ex. Graphic Design)",
      value,
      onChange: this.onChange,
      onKeyPress: this.onEnterKeyPress
    };

    let startrating = '<div style={{display: "block", width: "100%"}}>';
    startrating += '<div className="starcontainer">';
    startrating += '<span><i  aria-hidden="true" className={fa fa-star fa-lg Novice} onClick={this.handleRating.bind(this, "Average")} ></i> Average</span>';
    startrating += ' <span><i  aria-hidden="true" className={fa fa-star fa-lg Practitioner} onClick={this.handleRating.bind(this, "Good")} ></i> Good</span>';
    startrating += '<span><i  aria-hidden="true" className={fa fa-star fa-lg Expert} onClick={this.handleRating.bind(this, "Excellent")} ></i> Excellent</span>';
    startrating += '</div></div>';
    const skillstoapprove = []; // this array will be dispatched to action
    this.props.allEmployeeData.forEach((items, index) => {
      skillstoapprove.push({
        srno: index + 1,
        fullname: items.firstname + " " + items.lastname,
        managers: items.managers,
        role: items.role,
        level: <StarRating handleRatingChangeProp={this.ratingCheck.bind(this)} rating={items.level} disableClick={true}></StarRating>,
        action: (
          items.querystat === "" ?
            (<button
              type="submit"
              className="btn btn-primary float-left"
              onClick={e => {
                this.openModel(items, "Ask an Expert");
              }}
            >
              Ask
                </button>)
            : items.querystat === "S" ? <button type="submit" className="btn btn-primary float-left" onClick={e => { this.openModel(items, "Rate and Write a Review") }}>Rate and Write a Review</button>
              : items.querystat === "C" ? <button type="submit" className="btn btn-primary float-left" onClick={e => { this.openModel(items, "View Details") }}>View Details</button> : null)
      });
    });
    const data = {
      columns: [
        {
          label: "SR NO.",
          field: "srno",
          sort: "asc",
          width: 150
        },
        {
          label: "EMPLOYEE NAME",
          field: "fullname",
          width: 150
        },
        {
          label: "DELIVERY MANAGER",
          field: "managers",
          width: 150
        },
        {
          label: "ROLE",
          field: "role",
          width: 150
        },
        {
          label: "EXPERTISE LEVEL",
          field: "level",
          sort: "asc",
          width: 150
        },
        {
          label: "ACTION",
          field: "action",
          width: 150
        }
      ],
      rows: skillstoapprove // actual data to print in table body
    };

    return (
      <div>
        <div className="col-md-12">
          <div>
            <Header />
          </div>
          <div className="row">
            <div className="col-md-12 dashboard-container">
              <h1 class="dashboard-page-title">Past Queries</h1>
              <div className="row">
                <div className="add-skill-autosuggest-container input-group col-xl-3 col-lg-4 col-md-6 col-sm-6">
                  <Autosuggest
                    suggestions={suggestions}
                    onSuggestionsFetchRequested={
                      this.onSuggestionsFetchRequested
                    }
                    onSuggestionsClearRequested={
                      this.onSuggestionsClearRequested
                    }
                    getSuggestionValue={getSuggestionValue}
                    renderSuggestion={renderSuggestion}
                    inputProps={inputProps}
                    name="skillname"
                    value={this.state.value}
                    className="col-md-4 form-control"
                  />
                  <button
                    className="btn btn-add"
                    onClick={e => this.GetsendQuery(e)}
                  >
                    <i class="fa fa-search btn-add-icon" aria-hidden="true"></i>
                  </button>
                </div>
              </div>
              {
                this.props.querysenddata && this.props.querysenddata.length > 0 ?
                  (
                    <div>
                      <div className="dashboard-para-search-text">Result ({this.props.querysenddata.length})</div>
                      <div id="past-queries-table-layout">
                        <table className="table hideMob">
                          {
                            this.props.querysenddata.length !== 0 ?
                              (<thead>
                                <tr>
                                  <th width="20%">EMPLOYEE NAME</th>
                                  <th width="10%">DATE</th>
                                  <th width="17%">QUERY</th>
                                  <th width="7%">STATUS</th>
                                  <th width="16%">RESOLVED</th>
                                  <th width="17%">DM COMMENT</th>
                                  <th width="15%">ACTION</th>
                                </tr>
                              </thead>) : null
                          }
                          <tbody>
                            {this.props.querysenddata.length > 0 ?
                              this.props.querysenddata.map((items, key) => (
                                <Fragment>
                                  <tr>
                                    <td>
                                      <div className="ask-expert-table-col-name">
                                        {items.profilePic && items.profilePic !== "" ? <img src={API_URL + "/" + items.profilePic} /> : <img src={require("./../../assets/images/profile.jpg")} />}
                                        {items.firstname} {items.lastname}
                                      </div>
                                    </td>
                                       <td>{items.enteredOn.slice(0, 10)}</td>   
                                    <td style={{ "maxWidth": "150px", "wordBreak": "break-all" }}>
                                      {
                                        items.query === "" ? "-" :
                                          items.query.length <= 110 ? items.query : (<p> {items.query.slice(0, 110)} <span id={"dots-query" + key}></span> <span id={"more-query" + key} style={{ display: "none" }}> {items.query.slice(110, items.query.length)}</span> <span onClick={e => this.myFunction("-query" + key)} id={"myBtn-query" + key} className="ask-expert-ask-action text-nowrap">...Read more</span></p>)
                                      }
                                    </td>
                                    <td>{items.rating === "" ? "Open" : "Closed"}</td>
                                    <td>
                                      <div className="starcontainer">
                                        {items.rating === "No" ? <span><i aria-hidden="true" className="fa fa-star fa-lg Novice"></i>
                                          <i aria-hidden="true" className="fa fa-star fa-lg"></i>
                                          <i aria-hidden="true" className="fa fa-star fa-lg"></i>   {items.rating}</span>
                                          : items.rating === "Somewhat" ? <span><i aria-hidden="true" className="fa fa-star fa-lg Practitioner"></i>
                                            <i aria-hidden="true" className="fa fa-star fa-lg Practitioner"></i>
                                            <i aria-hidden="true" className="fa fa-star fa-lg "></i>   {items.rating}</span>
                                            : items.rating === "Yes" ? <span><i aria-hidden="true" className="fa fa-star fa-lg Expert"></i>
                                              <i aria-hidden="true" className="fa fa-star fa-lg Expert"></i>
                                              <i aria-hidden="true" className="fa fa-star fa-lg Expert"></i>   {items.rating}</span>
                                              : <span>Open</span>}
                                      </div>
                                    </td>
                                    <td style={{ "maxWidth": "150px", "wordBreak": "break-all" }}>
                                      {
                                        items.comment === "" ? "-" :
                                          <p>
                                            {items.comment.length <= 110 ? items.comment : <span>{items.comment.slice(0, 110)} <span id={"dots" + key}></span> <span id={"more" + key} style={{ display: "none" }}> {items.comment.slice(110, items.comment.length)}</span><span onClick={e => this.myFunction(key)} id={"myBtn" + key} className="ask-expert-ask-action text-nowrap">...Read more</span> </span>}
                                          </p>
                                      }
                                    </td>
                                    {items.status === "S" ? <td><span onClick={e => { this.openModel(items, "Rate and Write Reviews") }} className="ask-expert-ask-action"> Rate and Write a Review </span></td> : items.status === "C" ? <td><span onClick={e => { this.openModel(items, "View Details") }} className="ask-expert-ask-action"> View Details </span></td> : null}
                                  </tr>
                                </Fragment>
                              ))
                              : (
                                <tr>
                                  <td colSpan="7" className="border-top-0">
                                    <div className="d-flex flex-column align-items-center justify-content-center">
                                      <h2>No past queries found.</h2>
                                    </div>
                                  </td>
                                </tr>
                              )}
                          </tbody>
                        </table>
                        <div className="showMob past-queries-list-mob">
                          {
                            this.props.querysenddata.length > 0 ?
                              this.props.querysenddata.map((items, key) => (
                                <div className="past-queries-list-mob-item">
                                  <div className="d-flex justify-content-between align-items-center py-3">
                                    <div className="past-queries-list-mob-item-name">
                                      <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS6vDzm-UO315otGPTr_cWILvmR8-5VzLy3-IhDpc4h0V2LEYNz&amp;s" />
                                      <div>
                                        <p className="mb-0 past-queries-text-bold">{items.firstname} {items.lastname}</p>
                                        <p className="mb-0 past-queries-text">{items.designation || "Employee"}</p>
                                      </div>
                                    </div>
                                    <div className="past-queries-text-bold">{items.enteredOn.slice(0, 10)}</div>
                                  </div>
                                  <div className="row">
                                    <label className="col-3 past-queries-label mb-2">Status</label>
                                    <span className="col-9 past-queries-text mb-2">{items.rating === "" ? "Open" : "Closed"}</span>
                                  </div>
                                  <div className="row">
                                    <label className="col-3 past-queries-label mb-2">Rating</label>
                                    <div className="col-9 past-queries-text mb-2">
                                      <div className="starcontainer">
                                        {items.rating === "Average" ? <span>
                                          <i aria-hidden="true" className="fa fa-star fa-lg Novice"></i>
                                          {items.rating}</span>
                                          : items.rating === "Good" ? <span>
                                            <i aria-hidden="true" className="fa fa-star fa-lg Practitioner"></i>
                                            {items.rating}</span>
                                            : items.rating === "Excellent" ? <span>
                                              <i aria-hidden="true" className="fa fa-star fa-lg Expert"></i>
                                              {items.rating}</span>
                                              : <span>Open</span>}
                                      </div>
                                    </div>
                                  </div>
                                  <div className="row">
                                    <label className="col-3 past-queries-label mb-2">Query</label>
                                    <span className="col-9 past-queries-text mb-2">{items.query}</span>
                                  </div>
                                  <div className="row">
                                    <label className="col-3 past-queries-label mb-2">Comment</label>
                                    <span className="col-9 past-queries-text mb-2">{items.comment}</span>
                                  </div>
                                  <div className="row">
                                    <div className="col-12 past-queries-label justify-content-right">
                                      {items.status === "S" ? <span onClick={e => { this.openModel(items, "Rate and Write a Review") }} className="ask-expert-ask-action"> Rate and Write a Review </span> : null}
                                    </div>
                                  </div>
                                </div>
                              )) :
                              <div className="d-flex flex-column align-items-center justify-content-center p-3">
                                <h2>No past queries found.</h2>
                              </div>
                          }
                        </div>
                      </div>
                      {this.state.isModelOpen ? (
                        <AskExprtScreen modelOpen={this.state.isModelOpen} title={this.state.modalTitle} closeModal={this.close.bind(this)} empdata={this.state.dtaarr} sendQueryToexpert={this.sendQueryToexpert.bind(this)} />
                      ) : null}
                    </div>
                  )
                  :
                  <p className="noData">No Data Available!</p>
              }
            </div>
          </div>
        </div>
      </div>
    )
  }
}

Askexpert.propTypes = {
  dispatch: PropTypes.func.isRequired
};

const mapStateToProps = state => {
  return {
    allEmployeeData: state.askExpertReducer.employeeSkillsBySkill || [],
    querysendStatus: state.askExpertReducer.querysendStatus || [],
    querysenddata: state.askExpertReducer.querysenddata || [],
    allskills: state.skillReducer.allskills || []
  };
};

export default connect(mapStateToProps)(Askexpert);