import * as actionTypes from "./askExpertActionType";
import axios from "axios";
import { func } from "prop-types";
import { API_URL } from "./../../config";

export function getEmployeeList(srchData) {
  var headers = {
    "Content-Type": "application/json",
    "x-auth-token": localStorage.getItem("token")
  };
  return function (dispatch) {
    return axios
      .post(API_URL + `/api/employee/getEmployeeBySkill`, { srchData }, { headers })
      .then(res => {

        dispatch({
          type: actionTypes.FETCH_EMPLOYE_BY_SKILL,
          payload: res.data.data
        });
      });
  };
}

export function sendQueryToExpert(querydata) {
  var headers = {
    "Content-Type": "application/json",
    "x-auth-token": localStorage.getItem("token")
  };
  return function (dispatch) {
    return axios
      .post(API_URL + `/api/employee/sendQueryToExpert`, { querydata }, { headers })
      .then(res => {
        dispatch({
          type: actionTypes.SEND_QUERY_TO_EXPRT,
          payload: res.data.data
        });
        dispatch(getEmployeeList(querydata[0].data.skillname));
        dispatch(GetsendQuery(querydata[0].data.skillname));
      });
  };
}

export function sendQueryToExpertNew(querydata,srcval) {
  var headers = {
    "Content-Type": "application/json",
    "x-auth-token": localStorage.getItem("token")
  };
  return function (dispatch) {
    return axios
      .post(API_URL + `/api/employee/sendQueryToExpert`, { querydata }, { headers })
      .then(res => {
        dispatch({
          type: actionTypes.SEND_QUERY_TO_EXPRT,
          payload: res.data.data
        });

        // console.log(querydata[0].data.skillname , "querydata[0].data.skillname" , srcval);
      //  dispatch(getEmployeeList(querydata[0].data.skillname));
      dispatch(clearSearchQuery());
      if(srcval === "")
      {
        dispatch(GetsendQueryNew(""));
      }else{
        dispatch(GetsendQueryNew(srcval));
      }
        
      });
  };
}

export function GetsendQuery(srchvalue) {
  var headers = {
    "Content-Type": "application/json",
    "x-auth-token": localStorage.getItem("token")
  };
  return function (dispatch) {
    return axios
      .post(API_URL + `/api/employee/GetsendQueryData`, { srchvalue }, { headers })
      .then(res => {
        dispatch({
          type: actionTypes.GET_SEND_QUERY,
          payload: res.data.data
        });
      });
  };
}

export function GetsendQueryNew(srchvalue) {
  var headers = {
    "Content-Type": "application/json",
    "x-auth-token": localStorage.getItem("token")
  };
  return function (dispatch) {
    return axios
      .post(API_URL + `/api/employee/GetsendQueryDataNew`, { srchvalue }, { headers })
      .then(res => {
        dispatch({
          type: actionTypes.GET_SEND_QUERY,
          payload: res.data.data
        });
      });
  };
}

export function getExpertList(srchData) {
  var headers = {
    "Content-Type": "application/json",
    "x-auth-token": localStorage.getItem("token")
  };
  return function (dispatch) {
    return axios
      .post(API_URL + `/api/employee/getExpertBySkill`, { srchData }, { headers })
      .then(res => {
        dispatch({
          type: actionTypes.FETCH_EXPERT_BY_SKILL,
          payload: res.data.data
        });
      });
  };
}

export function clearSearchQuery() {
  return function (dispatch) {
    dispatch({
      type: actionTypes.CLEAR_SEARCH,
      payload: {}
    })
  }
}

export function clearExpertSearchQuery() {
  return function (dispatch) {
    dispatch({
      type: actionTypes.CLEAR_ASK_EXPERT_SEARCH,
      payload: {}
    })
  }
}




