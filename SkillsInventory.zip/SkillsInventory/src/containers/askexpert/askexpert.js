import React, { Component, useState } from "react";
import { toastr } from "react-redux-toastr";
import * as actions from "./askExpertAction";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import askExpertReducer from "./askExpertReducer";
import AskExprtScreen from "./askexprtscreen";
import StarRating from "./../../components/starRating/starRating";
import Header from "./../../components/header/header";
import Routing from "./../../routing";
import Autosuggest from "react-autosuggest";
import * as skillsactions from "./../skill/skillActions";
import { Tooltip } from 'react-bootstrap';
import { API_URL } from './../../config';
import { Redirect } from "react-router-dom";

let suggestedskills = [];
const getSuggestions = value => {
  const inputValue = value.trim().toLowerCase();
  const inputLength = inputValue.length;
  return inputLength === 0
    ? []
    : suggestedskills.filter(
      lang => lang.name.toLowerCase().slice(0, inputLength) === inputValue
    );
};

const getSuggestionValue = suggestion => suggestion.name;
const renderSuggestion = suggestion => <div>{suggestion.name}</div>;

class PastqueryComponent extends Component {
  state = {
    srchval: "",
    dtaarr: [
      { srno: "", empname: "", delmanager: "", role: "", exprtlevel: "" }
    ],
    isModelOpen: false,
    value: "",
    suggestions: [],
    skillName: "",
    modalTitle: ""
  };

  componentDidMount = (e) => {
  }

  getsrchval = e => {
    this.setState({
      srchval: e.target.value
    });
  };
  getEMpListBySkill = () => {
    if (this.state.value !== "" && this.state.value.trim()) {
      const { dispatch } = this.props;
      dispatch(actions.getEmployeeList(this.state.srchval)).then((res) => {
        if (this.props.allEmployeeData.length == 0) {
          toastr.warning("Warning!", "No expert available!", {
            showCloseButton: false,
            timeOut: 3000
          });
        }
      });
    } else {
      toastr.warning("Warning!", "Please Enter skill name", {
        showCloseButton: false,
        timeOut: 3000
      });
    }
  };

  openModel = (data, title) => {
    this.setState({
      dtaarr: data
    });
    this.setState({
      isModelOpen: true,
      modalTitle: title
    });
  };
  close = () => {
    this.setState({
      isModelOpen: false
    });
  };

  sendQueryToexpert = query => {
    const { dispatch } = this.props;
    dispatch(actions.sendQueryToExpert(query)).then(() => {
      toastr.success("Success", "Query sent to expert successfully.", {
        showCloseButton: false,
        timeOut: 3000
      });
    });
    this.setState({
      isModelOpen: false
    });
  };

  ratingCheck = e => { };

  onChangeSkillName(e) {
    this.setState({ skillName: e.target.value });
    this.setState({ message: "" });
    const { dispatch } = this.props;
    const skillname = { skillname: e.target.value };
    dispatch(skillsactions.ChangeStatus());
  }

  onSuggestionsFetchRequested = ({ value }) => {
    if (value.length <= 60) {
      this.setState({
        srchval: value,
        suggestions: getSuggestions(value)
      });
    } else {
      this.setState({
        srchval: value.slice(0, 60),
        suggestions: getSuggestions(value.slice(0, 60)),
        value: value.slice(0, 60)
      });
    }
  };

  onSuggestionsClearRequested = () => {
    this.setState({
      suggestions: []
    });
  };

  onChange = (event, { newValue }) => {
    this.setState({ srchval: event.target.innerText });
    this.setState({ value: newValue });
    const { dispatch } = this.props;
    const skillname = { skillname: event.target.value };
    dispatch(skillsactions.getAllSkillsFromCluster(skillname));
  };

  enterClick = () => {
  }

  onEnterKeyPress = e => {
    if (e.key === "Enter") {
      this.getEMpListBySkill();
    }
  };

  render() {
    if (!localStorage.getItem("token") ) {
      return <Redirect to="/" />;
    }
    suggestedskills = this.props.allskills;
    const { value, suggestions } = this.state;
    const inputProps = {
      placeholder: "Search by Skill (ex. Graphic Design)",
      value,
      onChange: this.onChange,
      onKeyPress: this.onEnterKeyPress
    };

    return (
      <div>
        <div className="col-md-12">
          <div>
            <Header />
          </div>
          <div className="row">
            <div className="col-md-12 dashboard-container">
              <h1 className="dashboard-page-title">Ask an Expert</h1>
              <div className="row">
                <div className="add-skill-autosuggest-container input-group col-xl-3 col-lg-4 col-md-6 col-sm-6">
                  <Autosuggest
                    suggestions={suggestions}
                    onSuggestionsFetchRequested={
                      this.onSuggestionsFetchRequested
                    }
                    onSuggestionsClearRequested={
                      this.onSuggestionsClearRequested
                    }
                    getSuggestionValue={getSuggestionValue}
                    renderSuggestion={renderSuggestion}
                    inputProps={inputProps}
                    name="skillname"
                    value={this.state.value}
                    className="col-md-4 form-control"
                    onSuggestionSelected={this.enterClick}
                  />
                  <button
                    className="btn btn-add"
                    onClick={e => this.getEMpListBySkill(e)}
                  >
                    <i className="fa fa-search btn-add-icon" aria-hidden="true"></i>
                  </button>
                </div>
              </div>
              <div className="dashboard-para-search-text">
                Experts {this.props.allEmployeeData.length}{" "}
              </div>
              <div>
                <table className="table hideMob ask-expert-table">
                  {this.props.allEmployeeData.length > 0 ? (
                    <thead>
                      <th width="25%">EMPLOYEE NAME</th>
                      <th width="25%">DELIVERY MANAGER</th>
                      <th width="20%">ROLE</th>
                      <th width="25%">EXPERTISE LEVEL</th>
                      <th width="5%">ACTION</th>
                    </thead>
                  ) : null}
                  <tbody>
                    {this.props.allEmployeeData.length > 0 ? this.props.allEmployeeData.map((items, key) => {
                      let email = '';
                      items.managers && items.managers !== 0 ?
                        email = (items.managers.toUpperCase()) :
                        email = '-. @mail.com';
                      return (
                        <tr>
                          <td>
                            <div class="ask-expert-table-col-name">
                              {items.profilepic !== "" ? <img src={API_URL + "/" + items.profilepic} /> : <img src={require("./../../assets/images/profile.jpg")} />}
                              {items.firstname} {items.lastname}
                            </div>
                          </td>
                          <td>{email.split('.')[0] + ' ' + email.split('.')[1].split('@')[0]}</td>
                          <td>{items.designation}</td>
                          <td>
                            <StarRating
                              name={items.firstname + items.lastname}
                              handleRatingChangeProp={this.ratingCheck.bind(
                                this
                              )}
                              rating={items.level}
                              disableClick={true}
                            ></StarRating>
                          </td>
                          <td>
                            <span
                              className="ask-expert-ask-action"
                              onClick={e => {
                                this.openModel(items, "Ask an Expert");
                              }}
                            >
                              Ask
                                </span>
                          </td>
                        </tr>
                      );
                    })
                      : null}
                  </tbody>
                </table>
                {this.props.allEmployeeData.length > 0 ? (
                  this.props.allEmployeeData.map((items, key) => (
                    <div className="showMob ask-expert-table-mob">
                      <div className="ask-expert-table-mob-col-name">
                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS6vDzm-UO315otGPTr_cWILvmR8-5VzLy3-IhDpc4h0V2LEYNz&amp;s" />
                        <div>
                          <p className="mb-0 font-weight-bold">
                            {items.firstname} {items.lastname}
                          </p>
                          <p className="mb-0">{items.designation}</p>
                        </div>
                      </div>
                      <div className="ask-expert-table-mob-col-rating">
                        <StarRating
                          name={items.firstname + items.lastname}
                          handleRatingChangeProp={this.ratingCheck.bind(this)}
                          rating={items.level}
                          disableClick={true}
                        ></StarRating>
                      </div>
                      <div>
                        <span
                          className="ask-expert-ask-action"
                          onClick={e => {
                            this.openModel(items, "Ask an Expert");
                          }}
                        >
                          Ask
                        </span>
                      </div>
                    </div>
                  ))
                ) : (
                    <div className="d-flex flex-column align-items-center justify-content-center">
                      <img
                        src={require("../../assets/images/ask-an-expert.jpg")}
                        className="img-fluid"
                      />
                      <h2>Need Help? Ask an Expert</h2>
                    </div>
                  )}
              </div>
              {this.state.isModelOpen ? (
                <AskExprtScreen
                  modelOpen={this.state.isModelOpen}
                  title={this.state.modalTitle}
                  closeModal={this.close.bind(this)}
                  empdata={this.state.dtaarr}
                  sendQueryToexpert={this.sendQueryToexpert.bind(this)}
                />
              ) : null}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

PastqueryComponent.propTypes = {
  dispatch: PropTypes.func.isRequired
};

const mapStateToProps = state => {
  return {
    allEmployeeData: state.askExpertReducer.employeeSkillsBySkill || [],
    querysendStatus: state.askExpertReducer.querysendStatus || [],
    allskills: state.skillReducer.allskills || []
  };
};

export default connect(mapStateToProps)(PastqueryComponent);
