import * as actionTypes from "./dashboardSkillActionTypes";

const dashboardskillReducer = (state = {}, action) => {
  switch (action.type) {
    case actionTypes.EDIT_SKILL:
      return Object.assign({}, state, {
        editinfo: action.payload.data
      });
    case actionTypes.DELETE_SKILL:
      return Object.assign({}, state, {
        deleteinfo: action.payload.data
      });
    case actionTypes.CHANGE_NOTIFICATION_STATUS:
      return Object.assign({}, state, {
        editinfo: action.payload.editinfo,
        deleteinfo: action.payload.deleteinfo
      });
    default:
      return state;
  }
};

export default dashboardskillReducer;
