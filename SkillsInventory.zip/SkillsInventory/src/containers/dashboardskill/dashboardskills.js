//This component is developed as a part of dashboard component. It contains Tab view of 	skills in sorted order of Exper, Intermeddiate and Novice level.
//This component is developed 	separately to avaoid complexity in developement.  This component contains other 3 	components PendingComponent,
//ApprovedComponent, EditComponent , all are located 	at  src / components / tabs

import React, { Component, Fragment } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import PendingComponent from "../../components/tabs/pendingComponent";
import ApprovedComponent from "../../components/tabs/approvedComponent";
import EditComponent from "../../components/tabs/editComponent";
import * as actions from "./dashboardSkillActions";
import * as dashboardAction from "../dashboard/dashboardAction";
import CommonDialogboxComponent from './../../components/tabs/commonDialogboxComponent';

class DashboardSkills extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isModelOpen: false,
      selectedRow: "",
      isComonDialgOpen: false,
      dialogmessage: ""
    };
  }

  getEditedRow = e => {
    this.setState({ isModelOpen: true });
    this.setState({ selectedRow: e });
  };

  getDeletedRow = e => {
  };

  openDialog = () => {
    this.setState({ isComonDialgOpen: true });
    this.setState({ dialogmessage: "Are you sure, Want to delete Skill...?" })
  }

  updateSkill = e => {
    const { dispatch } = this.props;
    Promise.resolve(dispatch(actions.editSkill(e))).then(res =>
      dispatch(dashboardAction.getAllSkillsByLevel())
    );
    this.setState({ isModelOpen: false });
  };

  closeeditbox() {
    this.setState({ isModelOpen: false });
  }

  render() {
    const pendingList = [];
    const approvedList = [];
    this.props.expertList.map(
      ele =>
        ele.skillStatus === "pending"
          ? pendingList.push(ele)
          : approvedList.push(ele)
    );

    return (
      <Fragment>
        <PendingComponent
          pendingList={pendingList}
          getdeletedrow={this.getDeletedRow}
          getselectedrow={this.getEditedRow}
        />
        <ApprovedComponent
          approvedList={approvedList}
          getselectedrow={this.getEditedRow}
          getdeletedrow={this.getDeletedRow}
        />
        {this.state.isModelOpen ? (
          <EditComponent
            modelOpen={this.state.isModelOpen}
            updateSkill={this.updateSkill}
            selectedData={this.state.selectedRow}
            closeeditbox={this.closeeditbox.bind(this)}
          />
        ) : null}
        {this.state.isComonDialgOpen ? (
          <CommonDialogboxComponent
            modelOpen={true}
            updateSkill={this.updateSkill}
            selectedData={this.state.selectedRow}
            closeeditbox={this.closeeditbox.bind(this)}
          />
        ) : null}
      </Fragment>
    );
  }
}

DashboardSkills.propTypes = {
  deleteSkill: PropTypes.object.isRequired,
  dispatch: PropTypes.func.isRequired
};

const mapStateToProps = state => {
  return {
    editinfo: state.dashboardskillReducer.editinfo || "",
    deleteinfo: state.dashboardskillReducer.deleteinfo || ""
  };
};

export default connect(mapStateToProps)(DashboardSkills);
