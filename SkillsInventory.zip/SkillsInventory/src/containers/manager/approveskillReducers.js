import * as actionTypes from "./approveskillActionTypes";

const approveskillReducer = (state = {}, action) => {
  switch (action.type) {
    case actionTypes.DIRECT_LIST:
      return Object.assign({}, state, {
        skillinfo: action.payload
      });

    case actionTypes.APPROVE_SKILL:
      return Object.assign({}, state, {
        approveskillinfo: action.payload
      });

    case actionTypes.APPROVE_MULTIPLE_SKILLS:
      return Object.assign({}, state, {
        multipleskills: action.payload
      });
    default:
      return state;
  }
};

export default approveskillReducer;
