import React, { Component } from "react";
import { NavLink, Link } from "react-router-dom";
import Header from "../../../../components/header/header";
import threestars from "./../../../../assets/images/3star.png";
import twostars from "./../../../../assets/images/2star.png";
import onestar from "./../../../../assets/images/1star.png";
import Chart from "react-google-charts";
import SimpleTabs from "../../../../components/tabs/tabs";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { withRouter } from 'react-router-dom';
import { Redirect } from "react-router-dom";
import * as action from './employeeProfileAction';
import EmployeeProfileTabs from './employeeProfileTabs';


const username = "Akash.Matre@harbingergroup.com";

class EmployeeProfile extends Component {
    constructor(props) {
        super(props);
        this.state = {
            expert: 0,
            practitioner: 0,
            novice: 0
        };
    }
    chartData = [];
    chartOptions = {
        pieHole: 0.7,
        legend: "none",
        colors: ["#02c155", "#faa519", "#30a1d4"],
        pieSliceTextStyle: {
            color: 'transparent',
        }
    };

    componentDidMount() {
        let username = sessionStorage.getItem("empUsername");
        const { dispatch } = this.props;
        dispatch(action.getAllUserInfo(username));
        dispatch(action.getAllSkillsByLevel(username));
    }

    onDashboard = () => {
             this.props.history.push('/dashboard');
        }

    render() {
        if (!localStorage.getItem("token")) {
            return <Redirect to="/" />;
        }
        let keys = Object.keys(this.props.employeeSkillsByLevel);
        let len = 0;
        if (keys.length) {
            this.chartData = [
                ["skilllevel", "numberofskill"],
                ["Expert", this.props.employeeSkillsByLevel.Expert.length],
                ["Practitioner", this.props.employeeSkillsByLevel.Practitioner.length],
                ["Novice", this.props.employeeSkillsByLevel.Novice.length]
            ];
            for (let key of keys) {
                len += this.props.employeeSkillsByLevel[key].length;
                if (key == "Novice")
                    this.state.novice = this.props.employeeSkillsByLevel[key].length;
                if (key == "Expert")
                    this.state.expert = this.props.employeeSkillsByLevel[key].length;
                if (key == "Practitioner")
                    this.state.practitioner = this.props.employeeSkillsByLevel[
                        key
                    ].length;
            }
        }

        return (
            <div className="">
                <div>
                    <Header />
                </div>
                <div className="col-md-12 dashboard-container">
                    <h2 className="dashboard-page-title">{this.props.userDetails.firstname} {this.props.userDetails.lastname}</h2>
                    <div className="row dash-sec1">
                        <div className="col-lg-3 col-12 box">
                            <Chart
                                chartType="PieChart"
                                width="100%"
                                height="350px"
                                data={this.chartData}
                                options={this.chartOptions}
                            />
                            <div className="charts-data-inside">
                                <h2>{this.state.novice + this.state.expert + this.state.practitioner}</h2>
                                <h4>Total Skills</h4>
                            </div>
                        </div>

                        <div className="col-lg-3 col-4 box">
                            <div className="skillbox expertbox">
                                <div className="row">
                                    <div className="col">
                                        <span className="skillbox-count expertcount">
                                            {this.state.expert}
                                        </span>
                                    </div>
                                    <div className="skillbox-circle expert-circle-star">
                                        <img
                                            src={threestars}
                                            alt="3 stars"
                                            className="img-fluid"
                                        />
                                    </div>
                                </div>
                                <h6> Expert</h6>
                            </div>
                        </div>

                        <div className="col-lg-3 col-4 box">
                            <div className="skillbox practitionerbox">
                                <div className="row">
                                    <div className="col">
                                        <span className="skillbox-count practitionercount">
                                            {this.state.practitioner}
                                        </span>
                                    </div>
                                    <div className="skillbox-circle practitionerbox-circle-star">
                                        <img
                                            src={twostars}
                                            alt="2 stars"
                                            className="img-fluid"
                                        />
                                    </div>
                                </div>
                                <h6>Practitioner</h6>
                            </div>
                        </div>

                        <div className="col-lg-3 col-4 box">
                            <div className="skillbox novicebox">
                                <div className="row">
                                    <div className="col">
                                        <span className="skillbox-count novicecount">
                                            {this.state.novice}
                                        </span>
                                    </div>
                                    <div className="skillbox-circle novice-circle-star">
                                        <img
                                            src={onestar}
                                            alt="1 star"
                                            className="img-fluid"
                                        />
                                    </div>
                                </div>
                                <h6> Novice</h6>
                            </div>
                        </div> 
                    </div>
                   
                    <div className="dash-tabs">                         
                             <button type="button" className="custom-btn float-right dashboardalign" onClick={this.onDashboard}>
                                Dashboard
                            </button>                         
                        <EmployeeProfileTabs
                            childData={this.props.employeeSkillsByLevel['Expert']}
                            practitionerData={
                                this.props.employeeSkillsByLevel['Practitioner']
                            }
                            noViceData={this.props.employeeSkillsByLevel['Novice']}
                            allUserData={this.props.userDetails}
                        />
                    </div>
                </div>
                <div />
            </div>
        );
    }
}

EmployeeProfile.propTypes = {
    dispatch: PropTypes.func.isRequired
};

const mapStateToProps = state => {
    return {
        userDetails: state.employeeProfileReducer.userDetailsEmployee || [],
        employeeSkillsByLevel: state.employeeProfileReducer.employeeSkillsByLevelEmoloyee || [],
    };
};

export default connect(mapStateToProps)(withRouter(EmployeeProfile));
