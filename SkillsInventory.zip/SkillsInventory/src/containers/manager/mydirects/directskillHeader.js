import React from "react";

function DirectsSkillHeader() {
  return (
    <tr className="hideMob">
      <th> SKILLSET</th>
      <th> LAST USED</th>
      <th> STATUS OF SKILLSET</th>
      <th> ACTION</th>
    </tr>
  );
}

export default DirectsSkillHeader;
