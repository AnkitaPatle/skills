import axios from "axios";
import * as actionTypes from "./mydirectsActionTypes";
import { API_URL } from "./../../../config";

export function getAllDirects() {
  var headers = {
    "Content-Type": "application/json",
    "x-auth-token": localStorage.getItem("token")
  };
  return function (dispatch) {
    return axios
      .get(API_URL + `/api/employee/allDirects`, { headers })
      .then(res => {
        dispatch({
          type: actionTypes.FETCH_ALL_DIRECTS,
          payload: res.data.data
        });
      });
  };
}
export function getAllDirectsforApproveAll() {
  var headers = {
    "Content-Type": "application/json",
    "x-auth-token": localStorage.getItem("token")
  };
  return function (dispatch) {
    return axios
      .get(API_URL + `/api/employee/allDirectsforapproveAll`, { headers })
      .then(res => {
        dispatch({
          type: actionTypes.FETCH_ALL_DIRECTS_APPROVED_ALL,
          payload: res.data.data
        });
      });
  };
}


export function getDirectDetails() {
  var headers = {
    "Content-Type": "application/json",
    "x-auth-token": localStorage.getItem("token")
  };
  return function (dispatch) {
    return axios
      .get(API_URL + `/api/employee/directDetails`, { headers })
      .then(res => {
        dispatch({
          type: actionTypes.FETCH_DIRECT_NAME,
          payload: res.data.data
        });
      });
  };
}

export function approveSkill(employeeAllSkill) {
  var headers = {
    "Content-Type": "application/json",
    "x-auth-token": localStorage.getItem("token")
  };
  return function (dispatch) {
    return axios
      .post(
        API_URL + `/api/employee/approveSkills`,
        { employeeAllSkill },
        { headers }
      )
      .then(res => {
        dispatch({
          type: actionTypes.APPROVE_SKILLS,
          payload: { data: res.data.data }
        });
      });
  };
}