import React, { Component } from "react";
import Modal from "react-bootstrap/Modal";
import Autosuggest from "react-autosuggest";
import * as actions from "./mydirectsActions";
import { connect } from "react-redux";
import ReactHover from 'react-hover';
import { toastr } from "react-redux-toastr";
import StarRating from './../../../components/starRating/starRating';
import {API_URL} from './../../../config';
import profileImg from '../../../assets/images/profile.jpg'

const customStyles = {
};

class CommentComponent extends Component {
    constructor(props) {
        super(props);
    console.log(this.props.skillData.skillData, "this.props.skillData.skillData");
        this.state = {
            isModelOpen: false,
            selectedRow: "",
            disable:false,
            modalIsOpen: this.props.modelOpen ? true : false,
            comment: "",
            skilldata: this.props.skillData.skillData,
            classes: this.props.empdata ?
                this.props.empdata.rating ?
                    this.props.empdata.rating == 'Average'
                        ? ["fa fa-star fa-lg Novice"] :
                        this.props.empdata.rating == 'Good' ?
                            ["fa fa-star fa-lg Practitioner"] :
                            this.props.empdata.rating == 'Excellent' ?
                                ["fa fa-star fa-lg Expert"] :
                                ["fa fa-star fa-lg Novice", "fa fa-star fa-lg", "fa fa-star fa-lg"] :
                    ["fa fa-star fa-lg Novice", "fa fa-star fa-lg", "fa fa-star fa-lg"] :
                ["fa fa-star fa-lg Novice", "fa fa-star fa-lg", "fa fa-star fa-lg"]
        };
        this.ratingExpert = "Average";
    }

    onChangeSkillName(e) {
    }

    onChangeExpertiseLevel(e) {
    }
    onChangeCurrentStatus(e) {
    }
    onChangeSelectedYear(e) {
    }

    openModal() {
        this.setState({ modalIsOpen: true });
    }

    ratingCheck = (rating) => {
        this.setState({ ratingExpert: rating });
    }
    getComment = (e) => {
        this.setState({
            comment: e.target.value
        })
    }
    handleRating = (incommingRating) => {
        if (incommingRating === "Average")
        {
            let classarray = Object.assign([], this.state.classes);
            classarray[0] = `fa fa-star fa-lg Novice`;
            classarray[1] = `fa fa-star fa-lg`;
            classarray[2] = `fa fa-star fa-lg`;
            this.setState({ classes: classarray });
        } else if (incommingRating === "Good")
        {
            let classarray = Object.assign([], this.state.classes);
            classarray[0] = `fa fa-star fa-lg Practitioner`;
            classarray[1] = `fa fa-star fa-lg Practitioner`;
            classarray[2] = `fa fa-star fa-lg`;
            this.setState({ classes: classarray });
        } else
        {
            let classarray = Object.assign([], this.state.classes);
            classarray[0] = `fa fa-star fa-lg Expert`;
            classarray[1] = `fa fa-star fa-lg Expert`;
            classarray[2] = `fa fa-star fa-lg Expert`;
            this.setState({ classes: classarray });
        }
        this.ratingExpert = incommingRating;
    }

    commentagainstSkill = () => {
        this.setState({disable:true})
        const skilldata = this.props.skillData.skillData;
        const comments = this.state.comment;
        if (comments !== "" && comments.trim())
        {
            var obj = new Object();
            obj.skilldata = skilldata;
            obj.comment = comments;
            return this.props.sendCommentToEmployee(obj);
        }
        else
        {
            toastr.warning("Warning!", "Please enter your Comment!", {
                showCloseButton: false,
                timeOut: 3000
            });
        }
        this.setState({disable:false})
    }

    render() {
        const skillname = this.state.skilldata.skillname && this.state.skilldata.skillname.charAt(0).toUpperCase() + this.state.skilldata.skillname.slice(1);

        return (
            <Modal backdrop="static"
                show={this.state.modalIsOpen}
                onHide={this.props.closeModal.bind(this)}
                centered
                className="ask-expert-modal"
            >
                <Modal.Header closeButton className="mx-3 px-0">
                    <Modal.Title>Add Comment</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div className="row">
                        <div className="col-md-12">
                            <div className="d-flex ask-expert-modal-user-info">
                                <div className="ask-expert-modal-user-info-left">
                                {this.state.skilldata.profilePic === "" || this.state.skilldata.profilePic === undefined ? <img
                                    src={profileImg}
                                    className="img-fluid rounded-circle"
                                /> : <img
                                    src={API_URL + "/" + this.state.skilldata.profilePic}
                                    className="img-fluid rounded-circle"
                                />}
                                    <div className="ask-expert-modal-user-info-summary">
                                        <div >
                                            <div>
                                                <span className="ask-expert-modal-user-info-name"> {this.state.skilldata.firstname} {this.state.skilldata.lastname} </span>
                                            </div>
                                            <div className="summary-info-row">
                                                <span className="ask-expert-modal-user-info-naame"  style={{fontSize:"14px"}}>Designation - </span>                     
                                                <span className="ask-expert-modal-user-info-skill"  style={{fontSize:"14px"}}> {this.state.skilldata.designation}</span>
                                            </div>
                                            <div>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div className="ask-expert-modal-user-info-right">
                                    <p className="ask-expert-modal-user-info-position">{skillname}</p>
                                    <StarRating name={this.state.skilldata.firstname + this.state.skilldata.lastname} handleRatingChangeProp={this.ratingCheck.bind(this)} rating={this.state.skilldata.level} disableClick={true}></StarRating>
                                </div>
                            </div>
                            <hr />

                            <div className="mt-3">
                                <label htmlFor="query-comment" className="ask-expert-modal-label"> Please write your comment here :</label>
                                <textarea class="form-control" rows="3" id="query-comment" maxLength="250" onChange={(e) => this.getComment(e)}></textarea>
                            </div>
                        </div>
                    </div>
                </Modal.Body>
                <Modal.Footer>
                    <button
                        className="ask-expert-action-cancel"
                        onClick={this.props.closeModal.bind(this)}
                    >
                        &nbsp; Cancel &nbsp;
              </button>
                    <button
                        className="ask-expert-action-save"
                        onClick={this.commentagainstSkill}
                        disabled = {this.state.disable}
                    >
                        Comment
              </button>
                </Modal.Footer>
            </Modal>
        )
    }
}

const mapStateToProps = state => {
    return {
    };
};
export default connect(mapStateToProps)(CommentComponent);
