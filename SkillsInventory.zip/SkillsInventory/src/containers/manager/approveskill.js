//The skills added by employee will be displayed to DM login. DM can approve the skill by clicking on Approve Skill  button.
//Skills approved by DM are available to Capdev Executive 	for further use.
//MDBDatatable and MDBBtn from mdbreact package are used to diaplay the list of employees and button for approval.
//MDBDatatable has built in functionality of pagination, 	sorting, search and filter, number of records to display.

import React, { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { MDBDataTable, MDBInput } from "mdbreact";
import { toastr } from "react-redux-toastr";
import * as actions from "./approvskillActions";
import Header from "../../components/header/header";
import Routing from "../../routing";
import EditComponent from "./../../components/tabs/editComponent";
import "./approveskill.css";

class ApproveSkillComponent extends Component {
  multipleskillinfo = [];
  state = {
    skillinfo: this.props.skillinfo,
    selectall: false,
    checkall: false,
    ischecked: false,
    showButton: true,
    message: "",
    isModalOpen: false,
    addDirectSkill: {},
    adskilmsg: ""
  };

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch(actions.DirectList()); // to display list of directs name and skills to be approved only.
  }

  // function to approve single skill in the list
  onApproveSkillClick = item => {
    const skillinfo = {
      username: item.username,
      skillname: item.skillname,
      level: item.level
    };
    const { dispatch } = this.props;
    dispatch(actions.ApproveSkill(skillinfo));
    dispatch(actions.DirectList());
    this.setState({ message: this.props.skillinfo.message });
  };

  // function o handle click event of particular checkbox
  handleCheckboxChange = (e, item, index) => {
    this.setState({ adskilmsg: "" });
    this.setState({ showButton: false });
    if (e.target.checked) {
      this.multipleskillinfo.push(item);
    } else {
      for (let i = 0; i < this.multipleskillinfo.length; i++) {
        if (
          this.multipleskillinfo[i].skillname === item.skillname &&
          this.multipleskillinfo[i].username === item.username
        ) {
          this.multipleskillinfo.splice(i, 1);
        }
      }
    }
    if (this.multipleskillinfo.length > 0) {
      this.setState({ showButton: false });
    } else {
      this.setState({ showButton: true });
    }
  };
  // function to handle click on "select all" checkbox placed in heders of table
  handleAllCheckboxChange = (skillstoapprove, data) => {
    this.setState({ adskilmsg: "" });
    if (skillstoapprove) {
      this.setState({ showButton: false });
    } else {
      this.setState({ showButton: true });
    }
    this.multipleskillinfo = [];
    for (let i = 0; i <= data.length - 1; i++) {
      if (skillstoapprove) {
        document.getElementById("chkbx" + i).checked = true;
        this.multipleskillinfo.push(data[i]);
      } else {
        document.getElementById("chkbx" + i).checked = false;
      }
    }
  };

  // function to dispatch action
  approvemultipleskill() {
    if (this.multipleskillinfo.length > 0) {
      const { dispatch } = this.props;
      dispatch(actions.ApproveMultipleSkills(this.multipleskillinfo));
      this.setState({ selectall: false });
      this.setState({ showButton: false });
      document.getElementById("chkall").checked = false;
      this.setState({ message: this.props.skillinfo.message });
      this.multipleskillinfo = [];
      this.setState({ adskilmsg: "" });
    }
  }

  // to identify whether state has been changed or not , on onChange event of checkbox
  // handleAllCheckboxChange will not identify the state
  componentDidUpdate() {
    if (this.state.selectall) {
      this.multipleskillinfo.push(...this.props.skillinfo.data);
    }
  }

  addskillDiredct = data => {
    this.setState({ isModalOpen: true });
    this.state.addDirectSkill = { username: data.username, status: "A" };
  };
  addSkillDirect = skillset => {
    const { dispatch } = this.props;
    dispatch(actions.AddDirectSkills(skillset)).then(data=>{
      toastr.success('Success', 'Skill added successfully.', {showCloseButton: false,
        timeOut: 3000})
    });
    this.setState({ isModalOpen: false });
    this.setState({ adskilmsg: this.props.skillinfo.addmessage });
  };
  close() {
    this.setState({ isModalOpen: false });
    this.setState({ adskilmsg: "" });
    this.setState({ message: "" });
  }

  render() {
    const skillstoapprove = []; // this array will be dispatched to action

    return (
      <div>
        <div className="col-md-12">
          <div>
            <Header />
          </div>
          <div className="row">
            <div className="col-md-12 dashboard-container">
              <div className="d-flex justify-content-between align-items-center">
                <h1 class="dashboard-page-title">Add Skills</h1>
                <button
                  type="submit"
                  id="approveAllbtn"
                  disabled={this.state.showButton}
                  className="custom-btn float-right"
                  onClick={e => {
                    this.approvemultipleskill();
                  }}
                >
                  Approve Skills
                </button>
              </div>

              <div className="col-md-12">
                {typeof this.props.skillinfo.data === "object" ? (
                  <table className="table">
                    <thead>
                      <tr>
                        <th width="5%">
                          <input
                            type="checkbox"
                            id="chkall"
                            onChange={e => {
                              this.handleAllCheckboxChange(
                                e.target.checked,
                                this.props.skillinfo.data
                              );
                            }}
                          />
                        </th>
                        <th width="40%">Direct Name</th>
                        <th width="25%">Skill Name</th>
                        <th width="20%">Level</th>
                        <th width="10%">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {this.props.skillinfo.data.map((item, index) => (
                        <tr className={item.checked ? "rowSelected" : ""}>
                          <td>
                            <input
                              type="checkbox"
                              id={"chkbx" + index}
                              key={item._id}
                              ischecked={this.state.ischecked}
                              onChange={e => {
                                this.handleCheckboxChange(e, item, index);
                              }}
                            />
                      </td>
                       <td>{item.username}</td>
                       <td>{item.skillname}</td>
                       <td>{item.level}</td>
                       <td>
                          <span onClick={this.addskillDiredct.bind(this,item)} className="textcolor">Add skill</span>
                        </td>
                       </tr>
                    ))} 
                    </tbody>
                  </table>                 
                ) : (
                  <div>
                    No Pending Skills to Approve
                  </div>
                )}

                {this.state.isModalOpen ? (
                  <EditComponent
                    modelOpen={this.state.isModalOpen}
                    addDirectSkill={this.state.addDirectSkill}
                    addSkillDirect={this.addSkillDirect}
                    close={this.close.bind(this)}
                  />
                ) : null}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

ApproveSkillComponent.propTypes = {
  DirectList: PropTypes.object.isRequired,
  dispatch: PropTypes.func.isRequired
};
const mapStateToProps = state => {
  return {
    skillinfo: state.approveskillReducer.skillinfo || []
  };
};

export default connect(mapStateToProps)(ApproveSkillComponent);
