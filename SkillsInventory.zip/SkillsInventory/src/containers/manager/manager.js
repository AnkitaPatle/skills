import React, { Component } from "react";
import Routing from "../../routing";
import { Button } from "react-md";
import DataTable from "react-data-table-component";
import Header from "../../components/header/header";

const data = [
  {
    id: 1,
    Name: "rahul chougule",
    year: "2019",
    button: "<button>11 </button>"
  },
  { id: 2, Name: "rohan rao", year: "2018" }
];

const columns = [
  {
    name: "Name",
    selector: "Name",
    sortable: true
  },
  {
    name: "year",
    selector: "year",
    sortable: true,
    center: true
  },
  {
    cell: () => (
      <Button raised primary>
        {" "}
        Remove as Manager{" "}
      </Button>
    ),
    button: true
  }
];
class ManagerComponent extends Component {
  render() {
    const { skills } = this.props;
    return (
      <div>
        <div className="col-md-12">
          <div>
            <Header />
          </div>
          <div className="row">
            <div className="col-md-12 dashboard-container">
              <div className="col-md-6">
                <form />
              </div>
              <DataTable
                title="Your Managers"
                columns={columns}
                data={data}
                striped
                selectableRows
                pagination="true"
                paginationPerPage="10"
              />
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default ManagerComponent;
