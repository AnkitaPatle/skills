import React, { Component } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { MDBDataTable, MDBBtn, MDBInput } from "mdbreact";
import * as actions from "./../approvskillActions";
import Header from "../../../components/header/header";
import Routing from "../../../routing";
import { NavLink, Link } from "react-router-dom";
import { Redirect } from "react-router-dom";
import "./../approveskill.css";


class ApproveSkillComponent extends Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch(actions.DirectList());
  }

  render() {
    if (!localStorage.getItem("token") ) {
      return <Redirect to="/" />;
    }
    const skillstoapprove = [];
    if (this.props.skillinfo.data) {
      this.props.skillinfo.data.forEach((item, index) => {
        skillstoapprove.push({
          username: item.username,
          skillname: item.skillname,
          action: (
        <Link className="nav-link" to={{pathname:"skill" , state:{name:"Akash"}}}>
            <button className="btn btn-primary float-left" onClick = {this.getrowdata}>Add New Skill </button>
        </Link>
          )
        });
      });
    }

    const data = {
      columns: [
        {
          label: "Direct Name",
          field: "directname",
          sort: "asc",
          width: 150
        },
        {
          label: "Current Skill",
          field: "Currentskill",
          width: 150
        },
        {
          label: "Add Skill",
          field: "addskill",
          width: 150
        }
      ],
      rows: skillstoapprove
    };

    return (
      <div>
        <div className="col-md-12">
          <div>
            <Header />
          </div>
          <div className="row">
            <div className="col-md-12 dashboard-container">
              <div className="sectiontitle">
                <h2>Add skill's</h2>
              </div>
              <div className="col-md-12">
                <MDBDataTable striped hover data={data} />
               </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

ApproveSkillComponent.propTypes = {
  DirectList: PropTypes.object.isRequired,
  dispatch: PropTypes.func.isRequired
};
const mapStateToProps = state => {
  return {
    skillinfo: state.approveskillReducer.skillinfo || []
  };
};

export default connect(mapStateToProps)(ApproveSkillComponent);