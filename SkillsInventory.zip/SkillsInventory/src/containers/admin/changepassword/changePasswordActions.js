import * as actionTypes from "./changePasswordActionsTypes";
import axios from "axios";
import {API_URL} from '../../../config';

export function changePassword(admin) {
  return function (dispatch) {
    var headers = {
      "Content-Type": "application/json",
      "x-auth-token": localStorage.getItem("token")
    };
    return axios
      .post(
        API_URL + `/api/changePassword`,
        { admin },
        {
          headers: headers
        }
      )
      .then(res => {
        dispatch({
          type: actionTypes.CHANGE_PASSWORD_SUCCESS,
          payload: res.data.data
        });
      });
  };
}
