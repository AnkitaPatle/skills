import * as actionTypes from "./changePasswordActionsTypes";

const changePasswordReducer = (state = {}, action) => {
  switch (action.type) {
    case actionTypes.CHANGE_PASSWORD_SUCCESS:
      return Object.assign({}, state, {
        passwordStatus: action.payload
      });

    default:
      return state;
  }
};
export default changePasswordReducer;
