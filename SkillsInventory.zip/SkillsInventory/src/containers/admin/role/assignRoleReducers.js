import * as actionTypes from "./assignroleActionTypes";
const assignRoleReducer = (state = {}, action) => {
  switch (action.type) {
    case actionTypes.FETCH_EMPLOYEE_SUCCESS:
      return Object.assign({}, state, {
        employeeList: action.payload
      });

    case actionTypes.CHANGE_MANAGER_ROLE_SUCCESS:
      return Object.assign({}, state, {
        managerRoleSuccess: action.payload
      });
    default:
      return state;
  }
};
export default assignRoleReducer;
