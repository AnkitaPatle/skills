import * as actionTypes from "./assignroleActionTypes";
import axios from "axios";
import { API_URL } from './../../../config';

export function getAllEmployeeList() {
  return function (dispatch) {
    var headers = {
      "Content-Type": "application/json",
      "x-auth-token": localStorage.getItem("token")
    };
    return axios
      .get(API_URL + `/api/listUsers`, {
        headers: headers
      })
      .then(res => {
        dispatch({
          type: actionTypes.FETCH_EMPLOYEE_SUCCESS,
          payload: res.data.data
        });
      });
  };
}

export function getAllEmployeeListForCapdev(empname) {
  var headers = {
    "Content-Type": "application/json",
    "x-auth-token": localStorage.getItem("token")
  };
  return function (dispatch) {
    return axios
      .post(API_URL + `/api/capdev/listAllEmployeeSkills`, { empname }, { headers }
      )
      .then(res => {
        dispatch({
          type: actionTypes.FETCH_EMPLOYEE_SUCCESS,
          payload: res.data.data
        });
      });
  };
}

export function changeRole(user) {
  return function (dispatch) {
    var headers = {
      "Content-Type": "application/json",
      "x-auth-token": localStorage.getItem("token")
    };
    return axios
      .post(
        API_URL + `/api/assignRole`,
        { user },
        {
          headers: headers
        }
      )
      .then(res => {
        dispatch({
          type: actionTypes.CHANGE_MANAGER_ROLE_SUCCESS,
          payload: res.data
        });
      });
  };
}
