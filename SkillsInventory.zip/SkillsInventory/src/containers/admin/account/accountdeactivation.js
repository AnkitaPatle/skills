import React, { Component } from "react";
import Header from "../../../components/header/header";
import Routing from "../../../routing";
import "./accountdeactivation.css";
import * as actions from "../role/assignRoleActions";
import { connect } from "react-redux";
import TableHeader from "./../../../components/deletedAccount/deletedAccountHeader";
import OperatorRow from "./../../../components/deletedAccount/deletedAccountRow";
import PropTypes from "prop-types";
import { Redirect } from "react-router-dom";

class AccountdeactivationComponent extends Component {
  componentDidMount() {
    const { dispatch } = this.props;
    dispatch(actions.getAllEmployeeList());
  }

  deActivateEmployeeAccount(e) {
    window.alert("Sry Admin...functionality will coming soon...");
  }

  render() {
    if (!localStorage.getItem("token") ) {
      return <Redirect to="/" />;
    }
    return (
      <div>
        <div className="col-md-12">
          <div>
            <Header />
          </div>
          <div className="row">
            <div className="col-md-2">
              <Routing />
            </div>
            <div className="col-md-9">
              <div className="sectiontitle">
                <h2> Assign Role</h2>
              </div>
              <div className="col-md-6">
                <form>
                  <div className="form-group">
                    <input
                      type="text"
                      name="txtsearch"
                      placeholder="Search..."
                      className="form-control searchbox"
                    />
                    <button className="btn btn-primary">Search</button>
                  </div>
                </form>
              </div>
              <div className="colorcombo">
                {this.props.roleStatus.data !== ""
                  ? this.props.roleStatus.data
                  : ""}
              </div>
              <br />
              <div className="col-md-6">
                <table className="table table-bordered table-hover table-secondary">
                  <thead>
                    <tr>
                      <TableHeader
                        operatorHeaderList={this.props.employeeList}
                      />
                    </tr>
                  </thead>
                  <tbody>
                    {this.props.employeeList.map((prd, idx) => (
                      <OperatorRow
                        key={idx}
                        row={prd}
                        deletedSelectedAction={this.deActivateEmployeeAccount.bind(
                          this
                        )}
                      />
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

AccountdeactivationComponent.propTypes = {
  getAllEmployeeList: PropTypes.object.isRequired,
  dispatch: PropTypes.func.isRequired
};

const mapStateToProps = state => {
  return {
    employeeList: state.assignRoleReducer.employeeList || [],
    roleStatus: state.assignRoleReducer.managerRoleSuccess || ""
  };
};

export default connect(mapStateToProps)(AccountdeactivationComponent);
