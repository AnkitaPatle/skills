import * as actionTypes from "./mapskillsActionTypes";

const mapskillsReducer = (state = {}, action) => {
  switch (actionTypes) {
    case actionTypes.MAP_SKILL_TO_PARENT:
      return Object.assign({}, state, {
        mapskill: action.payload
      });

    case actionTypes.MAPPED_SKILL_LIST:
      return Object.assign({}, state, {
        mappedkilllist: action.payload
      });

    default:
      return state;
  }
};

export default mapskillsReducer;
