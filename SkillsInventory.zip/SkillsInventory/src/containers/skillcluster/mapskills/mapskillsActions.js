import axios from "axios";
import * as actionTypes from "./mapskillsActionTypes";
import {API_URL} from './../../../config';

export function MapSkills(mapskill) {
  return function (dispatch) {
    var headers = {
      "Content-Type": "application/json",
      "x-auth-token": localStorage.getItem("token")
    };

    return axios
      .post(
        API_URL + "/api/mapSkill",
        { mapskill },
        { headers: headers }
      )
      .then(res => {
        dispatch({
          type: actionTypes.MAP_SKILL_TO_PARENT,
          payload: res.data.data
        });
      });
  };
}

export function getMappedSkillList() {
  return function (dispatch) {
    var headers = {
      "Content-Type": "application/json",
      "x-auth-token": localStorage.getItem("token")
    };
    return axios
      .get(API_URL + `/api/mappedlist`, {
        headers: headers
      })
      .then(res => {
        dispatch({
          type: actionTypes.MAPPED_SKILL_LIST,
          payload: res.data.data
        });
      });
  };
}
