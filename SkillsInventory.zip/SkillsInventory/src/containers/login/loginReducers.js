import * as actionTypes from "./loginActionTypes";
const loginReducer = (state = {}, action) => {
  switch (action.type) {
    case actionTypes.LOGIN_SUCCESS:
      return Object.assign({}, state, {
        loginInfo: action.payload
      });
    default:
      return state;
  }
};
export default loginReducer;
