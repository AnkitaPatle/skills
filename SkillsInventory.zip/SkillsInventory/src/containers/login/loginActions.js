import * as actionTypes from "./loginActionTypes";
import axios from "axios";
import { API_URL } from "./../../config";

function EmployeeLogin(employee) {
  return async function (dispatch) {
    try
    {
      const res = await axios.post(
        API_URL + `/api/ldapLogin`,
        employee
      );
      sessionStorage.setItem("token", res.headers["x-auth-token"]);
      await localStorage.setItem("token", res.headers["x-auth-token"]);
      if (res.data.error == undefined)
      {
        if (res.data.data.status === undefined || res.data.data.status === "D")
        {
          localStorage.setItem("errormessage", res.data.data);
        }
        else
        {
          sessionStorage.setItem("role", res.data.data.role);
          localStorage.setItem("role", res.data.data.role);
          localStorage.setItem("token", res.headers["x-auth-token"]);
          localStorage.setItem("userName", res.data.data.firstName);
          localStorage.setItem("userInfo", JSON.stringify(res.data.data));
          sessionStorage.setItem("userDetails", JSON.stringify(res.data.data));
          dispatch({ type: actionTypes.LOGIN_SUCCESS, payload: res.data.data });
        }
      } else
      {
        localStorage.setItem("errormessage", res.data.error);
        dispatch({ type: actionTypes.LOGIN_SUCCESS, payload: res.data.data });
      }
    } catch (err) { }
  };
}

export default EmployeeLogin;
