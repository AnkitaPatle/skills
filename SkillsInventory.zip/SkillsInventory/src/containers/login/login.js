//This component allows employees and admin to login. This component is integrated with
//LDAP server by which user can log-in with his/her windows credentials. LDAP details are 	maintained by CIS team.
//Only admin user has separate username and password, than LDAP details.

import React, { Component } from "react";
import { Redirect } from "react-router-dom";
import "./login.css";
import EmployeeLogin from "./loginActions";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import logo from "./../../assets/images/login-bg.png";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import Dashboard from "./../dashboard/dashboard";

class LoginComponent extends Component {
  constructor(props) {
    super(props);
    document.title = "HARBINGER SKILL CLOUD";
    localStorage.removeItem("errormessage");
  }
  state = {
    UserName: "",
    Password: "",
    redirect: false,
    message: "",
    errMessage: "",
    usernameRequired: false,
    passwordRequired: false,
    rememberMe: false
  };

  componentDidMount() {
    let rememberMe = localStorage.getItem("rememberMe") == 'true';
    let UserName = rememberMe ? localStorage.getItem("UserName") : "";
    let Password = rememberMe ? localStorage.getItem("Password") : "";
    this.setState({ UserName, Password, rememberMe });
  }

  onChangeUserName(e) {
    this.setState({
      UserName: e.target.value,
      message: "",
      usernameRequired: false
    });
    localStorage.errormessage = "";
    if (e.target.value.trim() == "") {
      this.setState({
        usernameRequired: true
      });
    }
  }

  onChangePasswordName(e) {
    this.setState({
      Password: e.target.value,
      message: "",
      passwordRequired: false
    });
    localStorage.errormessage = "";

    if (e.target.value.trim() == "") {
      this.setState({
        passwordRequired: true
      });
    }
  }

  onChangeRememberMe = event => {
    const input = event.target;
    const value = input.type === "checkbox" ? input.checked : input.value;
    this.setState({ [input.name]: value });
  };

  login = () => {
    let UserName = this.state.UserName;
    let Password = this.state.Password;
    let rememberMe = this.state.rememberMe;
    localStorage.setItem("rememberMe", rememberMe);
    localStorage.setItem("UserName", rememberMe ? UserName : "");
    localStorage.setItem("Password", rememberMe ? Password : "");
    if (UserName !== "" && Password !== "") {
      if (UserName.includes("@")) {
        UserName = UserName;
      } else if (UserName !== "admin") {
        UserName += "@harbingergroup.com";
      }
      if (this.props.login(UserName, Password) === undefined) {
        this.setState({
          errMessage: localStorage.getItem("errormessage")
        });
      }
    }
  };

  handleKeyPress = event => {
    if (event.key === "Enter") {
      this.login();
    }
  };

  render() {
    if (localStorage.getItem("token") !== "undefined") {
      if (sessionStorage.getItem("token")) {
        return <Redirect to="/dashboard" />;
      }
    }

    return (
      <div className="login-form">
        <div className="fadeIn form-title">
          <p className="form-title-welcome d-lg-none">Welcome to </p>
          <span className="form-title-light">HARBINGER </span>
          <span className="form-title-bold">SKILL CLOUD</span>
        </div>

        <div id="formContent" className="login-form-content">
          <div className="">
            <p className="error-message position-relative text-left">
              {localStorage.getItem("errormessage")}
            </p>
          </div>
          <div className="form-label">
            <label htmlFor="UserName">Username</label>
          </div>

          <div className="input-group mb-4">
            <div className="input-group-prepend">
              <span className="input-group-text">
                <i className="icon icon-username color-gray" />
              </span>
            </div>
            <input
              type="text"
              className="form-control"
              name="UserName"
              id="UserName"
              placeholder="Username"
              value={this.state.UserName}
              onChange={this.onChangeUserName.bind(this)}
              maxLength={60}
            />
            {this.state.usernameRequired ? (
              <div className="position-relative w-100">
                <p className="error-message">Username is Required</p>
              </div>
            ) : null}
          </div>

          <div className="form-label">
            <label htmlFor="Password">Password</label>
          </div>

          <div className="input-group mb-4">
            <div className="input-group-prepend">
              <span className="input-group-text">
                <i className="icon icon-password color-gray" />
              </span>
            </div>
            <input
              type="password"
              className="form-control"
              name="Password"
              id="Password"
              placeholder="Password"
              value={this.state.Password}
              onChange={this.onChangePasswordName.bind(this)}
              maxLength={60}
              onKeyPress={this.handleKeyPress}
            />
            {this.state.passwordRequired ? (
              <div className="position-relative w-100">
                <p className="error-message">Password is Required</p>
              </div>
            ) : null}
          </div>

          <div className="text-left mt-1 mb-4">
            <div className="custom-control custom-checkbox custom-checkbox-field">
              <input
                type="checkbox"
                className="custom-control-input"
                checked={this.state.rememberMe}
                onChange={this.onChangeRememberMe}
                id="rememberMe"
                name="rememberMe"
              />
              <label className="custom-control-label" htmlFor="rememberMe">
                Remember me
              </label>
            </div>
          </div>

          <div className="">
            <button
              type="submit"
              onClick={this.login}
              className="btn btn-block mybtn btn-primary custom-btn"
              disabled={this.state.UserName == "" || this.state.Password == ""}
            >
              Sign In
            </button>
          </div>
          <div style={{ marginTop: "5px" }}>
            <img src={logo} alt="Logo" />
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    loginInfo: state.loginReducer.loginInfo || {}
  };
};

const mapDispatchToProps = dispatch => {
  return {
    login: (UserName, Password) => {
      dispatch(EmployeeLogin({ UserName, Password }));
    }
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(LoginComponent);
