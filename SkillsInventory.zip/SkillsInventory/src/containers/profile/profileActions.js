import * as actionTypes from "./profileActionTypes";
import axios from "axios";
import {API_URL} from './../../config'

export function getAllUserInfo() {
  return function (dispatch) {
    var headers = {
      "Content-Type": "application/json",
      "x-auth-token": localStorage.getItem("token")
    };
    return axios
      .get(API_URL + `/api/userDetails`, {
        headers: headers
      })
      .then(res => {
        dispatch({
          type: actionTypes.FETCH_USER_SUCCESS,
          payload: res.data.data
        });
      });
  };
}

export function editUserProfile(profileData) {
  return function (dispatch) {
    var headers = {
      "Content-Type": "application/json",
      "x-auth-token": localStorage.getItem("token")
    };
    return axios
      .post(
        API_URL + `/api/editProfile`,
        { profileData },
        { headers }
      )
      .then(res => {
        dispatch({
          type: actionTypes.UPDATE_PROFILE_SUCCESS,
          payload: res.data.data
        });
      });
  };
}

export function getProfilePicUrl(profileData) {
  return function (dispatch) {
    var headers = {
      "Content-Type": "application/json",
      "x-auth-token": localStorage.getItem("token")
    };
    return axios
      .get(
        API_URL + `/api/getProfilePicUrl`,
        { headers }
      )
      .then(res => {
        dispatch({
          type: actionTypes.GET_PROFILE_URL,
          payload: res.data.data
        });
      });
  };
}

export function uploadProfilePic(profilePicData) {
  return function (dispatch) {
    var headers = {
      "x-auth-token": localStorage.getItem("token")
    };
    return axios
      .post(
        API_URL + `/api/editProfilePic`,
        { profilePicData },
        { headers }
      )
      .then(res => {
        dispatch({
          type: actionTypes.GET_PROFILEPIC_RES,
          payload: res.data.data
        });
      });
  };
}
