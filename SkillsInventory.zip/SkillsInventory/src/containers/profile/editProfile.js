import React, { Component } from "react";
import "./editprofile.css";
import { NavLink, Redirect } from "react-router-dom";
import Autosuggest from "react-autosuggest";
import { toastr } from "react-redux-toastr";
import * as actions from "./profileActions";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import profileReducer from './profileReducers';
import { API_URL } from './../../config';
import logo from './../../assets/images/logo1.png';

class EditProfile extends Component {
  constructor(props) {
    super(props);
    this.state = {
       profilepic: "",
      profpicflag: "NA",
      reload: "",
      disable:false,
    };
  }

  getdepartment = e => {
    this.setState({ department: e.target.value });
  };
  getcompany = e => {
    this.setState({ company: e.target.value });
  };
  getlocation = e => {
    this.setState({ location: e.target.value });
  };
  getrole = e => {
    this.setState({ role: e.target.value });
  };

  ediProfile = () => {
    this.setState({disable:true});
    const { dispatch } = this.props;

    // console.log(this.state.profpicflag ,"this.state.profpicflag");
    if (this.state.profpicflag === "NA")
    {
      // toastr.warning("Warning!", "Please Upload Profile Picturee!", {
      //   showCloseButton: false
      // });
      this.setState({
        toDashboard: true
      });
      return <Redirect to="/dashboard" />;
    }
    else
    {
      dispatch(actions.editUserProfile(this.state)).then(data => {
        toastr.success("Success", "Profile Picture Uploaded Successfully.", {
          showCloseButton: false,
          timeOut: 3000
        });
        this.setState({disable:false});
        this.setState({
          toDashboard: true
        });
        return <Redirect to="/dashboard" />;
      });
    }
  };

  getBase64(file, cb) {
    let reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = function () {
      cb(reader.result);
    };
    reader.onerror = function (error) {
      console.log("Error: ", error);
    };
  }

  onChangeHandler = event => {
    let idCardBase64 = "";
    this.getBase64(event.target.files[0], result => {
      let fileExt = result.split(";base64,")[0].split("/")[1]
    if(fileExt === "jpg" || fileExt === "png" || fileExt === "jpeg")
    {
      this.setState({ profilepic: result, profpicflag: "A" }, () => {
      });
    }
    else{
      toastr.warning("Warning!", "Please upload Profile Picture in JPG,PNG,JPEG format only!", {
        showCloseButton: false,
        timeOut: 3000
      });
    }  
    });
  };
  getProfilePicUrl = () => {
    const { dispatch } = this.props;
    dispatch(actions.getProfilePicUrl(this.state)).then(data => {
      toastr.success("Success", "Profile Edited Successfully.", {
        showCloseButton: false,
        timeOut: 3000
      });
    });
  }

  componentDidMount() {
    const { dispatch } = this.props;
    dispatch(actions.getAllUserInfo()).then(res => {
     if(this.props.users.profilePic !== "")
     {
      this.setState({profilepic:API_URL+"/"+this.props.users.profilePic})
     }
    });
  }

  changeState = () => {
    this.setState({ reload: "" }, () => {
    })
  }
  render() {
    const userdetails = JSON.parse(localStorage.getItem("userInfo"));
    if (this.state.toDashboard === true)
    {
      return <Redirect to="/dashboard" />;
    }

    return (
      <div className="login-form">
        <div className="form-title profile-title">
          <NavLink to="/dashboard"><img src={logo} /></NavLink>
        </div>

        <div className="login-form-content position-relative">
          <div className="edit-profile-img">

          {this.state.profilepic ? <img
              src={this.state.profilepic}
              className="img-fluid rounded-circle"
            /> : <img
                src={require("../../assets/images/profile.jpg")}
                className="img-fluid rounded-circle"
              />}

          </div>
          <div className="img-upload-container">
            <span className="image-upload icon icon-edit">
              <input
                type="file"
                style={{ opacity: 0 }}
                onChange={this.onChangeHandler}
                name="profpic"
                encType="multipart/form-data"
                title="Change the photo that appears in your profile. This may open a new window."
              />
            </span>
          </div>
          <div className="profile-info-row">
            <p className="profile-info-row-heading">
              {this.state.firstName} {this.state.lastname}
            </p>
          </div>

          <div className="row">
            <div className="col-sm-6 col-12">
              <div className="form-group text-left">
                <label htmlFor="label-company">
                  <b>Company</b> {this.state.companyName}
                </label>
                <p className="break-word" style={{height:"10%"}}>{userdetails.companyName}</p>
              </div>
            </div>
            <div className="col-sm-6 col-12">
              <div className="form-group text-left">
                <label htmlFor="label-dept"><b>Department</b></label>
                <p className="break-word" style={{height:"10%"}}>{userdetails.department}</p>
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-sm-6 col-12">
              <div className="form-group text-left">
                <label htmlFor="label-location"><b>Location</b></label>
                <p className="break-word" style={{height:"10%"}}>{userdetails.location}</p>
              </div>
            </div>
            <div className="col-sm-6 col-12">
              <div className="form-group text-left">
                <label htmlFor="label-role"><b>Role</b></label>
                <p className="break-word" style={{height:"10%"}}>{userdetails.designation}</p>
              </div>
            </div>
          </div>
          <div className="profile-action">
            <NavLink className="btn edit-btn" to="/dashboard" onClick={this.changeState}>
              Cancel
            </NavLink>
            <button
              type="button"
              className="btn continue-btn"
              onClick={e => this.ediProfile(e)}
              disabled={this.state.disable}
            >
              Save
            </button>
          </div>
        </div>
      </div>
    );
  }
}

EditProfile.propTypes = {
  dispatch: PropTypes.func.isRequired
};
const mapStateToProps = state => {
  return {
    users: state.profileReducer.users || [],
    usersData: state.profileReducer.usersData || []

  };
};
export default connect(mapStateToProps)(EditProfile);
